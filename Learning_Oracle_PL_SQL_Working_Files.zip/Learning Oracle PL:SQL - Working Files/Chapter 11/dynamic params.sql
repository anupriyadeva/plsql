SET SQLFORMAT ANSICONSOLE
SET PAGESIZE 30
SET LINESIZE 200

SELECT *
  FROM animal

DECLARE
  v_panda_species VARCHAR2(30) := 'Melanoleuca';
  v_zebra_species VARCHAR2(30) := 'Equids';
BEGIN
  -- pass parameters to SQL statement to encourage Oracle compiler to reuse
  -- compiled version of code
  EXECUTE IMMEDIATE 'UPDATE animal SET animal_species = :1 WHERE animal_name = :2'
    USING v_zebra_species, 'Zebra';
  -- passing parameters as text withing dynamic SQL does not promote reuse
  EXECUTE IMMEDIATE 'UPDATE animal SET animal_species = ' || '''' || v_panda_species || '''' ||
                    ' WHERE animal_name = ''Panda''';
END;

-- dynamic DDL with parameters as well
CREATE OR REPLACE PROCEDURE table_dropper ( p_table VARCHAR2 ) IS
  e_not_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_not_exists,-903);
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE :1'
    USING p_table;
EXCEPTION
  WHEN e_not_exists THEN
    DBMS_OUTPUT.PUT_LINE('Table ' || p_table || ' does not exist');
END;

BEGIN
  table_dropper('ABC');
END;

CREATE OR REPLACE TYPE v_n_t AS TABLE OF NUMBER;

-- pass non-scalar parameters
DECLARE
  v_id v_n_t := v_n_t();
BEGIN
  v_id.EXTEND(2);
  v_id(1) := 1;
  v_id(2) := 2;
--  EXECUTE IMMEDIATE 'BEGIN DBMS_OUTPUT.PUT_LINE(:1.COUNT); END;'
--     USING v_id;
  EXECUTE IMMEDIATE 'DECLARE v v_n_t; BEGIN v := :1; DBMS_OUTPUT.PUT_LINE(v.COUNT); END;'
     USING IN v_id;
END;

-- dynamic forall statement
DECLARE
  v_id v_n_t := v_n_t();
BEGIN
  v_id.EXTEND(2);
  v_id(1) := 1;
  v_id(2) := 2;
  FORALL counter IN 1..2
    EXECUTE IMMEDIATE 'UPDATE animal SET animal_name = animal_name || '':1'' WHERE animal_id = :1'
    USING v_id(counter);
END;

