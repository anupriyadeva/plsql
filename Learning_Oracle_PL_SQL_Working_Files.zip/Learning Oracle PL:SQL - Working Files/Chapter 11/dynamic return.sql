DROP TABLE animal;

CREATE TABLE animal
( animal_id   NUMBER,
  animal_name VARCHAR2(30) );
INSERT INTO animal VALUES(1,'Panda');
INSERT INTO animal VALUES(2,'Zebra');
COMMIT;

SET SQLFORMAT ANSICONSOLE
SET LINESIZE 200
SET PAGESIZE 100

SELECT *
  FROM animal
  
-- specify OUT parameter for dynamic SQL
DECLARE
  v_animal_id   NUMBER := 1;
  v_animal_name VARCHAR2(30) := 'Tiger';
  v_actual_id   NUMBER;
BEGIN
  EXECUTE IMMEDIATE 'UPDATE animal SET animal_name = :1 WHERE animal_id = :2 RETURNING animal_id INTO :3'
    USING v_animal_name, v_animal_id, OUT v_actual_id;
  DBMS_OUTPUT.PUT_LINE('Rows Updated:' || SQL%ROWCOUNT);
  DBMS_OUTPUT.PUT_LINE('ID Updated:  ' || v_actual_id);
END;

-- specify IN AND OUT parameter for dynamic SQL
DECLARE
  v_animal_id   NUMBER := 1;
  v_animal_name VARCHAR2(30) := 'Tiger';
BEGIN
  EXECUTE IMMEDIATE 'UPDATE animal SET animal_name = :1 WHERE animal_id = :2 RETURNING animal_id INTO :3'
    USING v_animal_name, IN v_animal_id, OUT v_animal_id;
  DBMS_OUTPUT.PUT_LINE('Rows Updated:' || SQL%ROWCOUNT);
  DBMS_OUTPUT.PUT_LINE('ID Updated:  ' || v_animal_id);
END;

CREATE OR REPLACE TYPE v_n_t AS TABLE OF NUMBER;

-- Missing INTO keyword?
DECLARE
  v v_n_t := v_n_t();
  vv number;
BEGIN
  v.EXTEND(2);
  v(1) := 2;
  v(2) := 1;
  EXECUTE IMMEDIATE 'DECLARE
                       v2 v_n_t := v_n_t();
                     BEGIN
                       UPDATE animal SET animal_name = ''Bob''
                       WHERE animal_id IN ( SELECT column_value
                                              FROM TABLE(CAST(:1 AS v_n_t))) RETURNING animal_id BULK COLLECT INTO v2;
                       :2 := v2;
                     END;'
  USING v, OUT v;
  FOR counter IN 1..v.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE(v(counter));
  END LOOP;
END;