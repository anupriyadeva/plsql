
BEGIN
  drh.dynamic_stuff('CREATE TABLE abc (col1 NUMBER)');
END;

SELECT *
  FROM all_tab_privs
 WHERE privilege = 'INHERIT PRIVILEGES'
   AND grantor = 'DRH2'

REVOKE INHERIT PRIVILEGES ON USER drh2 FROM PUBLIC
GRANT INHERIT PRIVILEGES ON USER drh2 TO drh

SELECT *
  FROM user_sys_privs