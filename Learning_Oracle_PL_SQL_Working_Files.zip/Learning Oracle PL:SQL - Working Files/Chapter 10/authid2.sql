BEGIN
  drh.show_animal(1);
END;

CREATE TABLE animal
( animal_id   NUMBER,
  animal_name VARCHAR2(30) );
  
INSERT INTO animal
VALUES(1,'Elephant','Bob');

INSERT INTO animal
VALUES(2,'Gorilla');

COMMIT;
