-- create function that is only accessible by specific procedure
CREATE OR REPLACE FUNCTION a_func ( p_id NUMBER )
                RETURN NUMBER
                ACCESSIBLE BY (a_proc) AS
BEGIN
  RETURN(p_id * 2);
END;

-- create procedure to call accessible function
CREATE OR REPLACE PROCEDURE a_proc AS
BEGIN
  DBMS_OUTPUT.PUT_LINE(a_func(11));
END;

BEGIN
  a_proc;
END;

-- try to call function directly
BEGIN
  DBMS_OUTPUT.PUT_LINE(a_func(11));
END;

-- try to call function from anothee proc
CREATE OR REPLACE PROCEDURE another_proc AS
BEGIN
  DBMS_OUTPUT.PUT_LINE(a_func(11));
END;

-- recreate function to be accessible by two procedures and user
-- the PROCEDURE keyword
CREATE OR REPLACE FUNCTION a_func ( p_id NUMBER )
                  RETURN NUMBER
                  ACCESSIBLE BY (PROCEDURE a_proc,PROCEDURE another_proc) AS
BEGIN
  RETURN(p_id * 2);
END;

-- create accessible package
CREATE OR REPLACE PACKAGE a_pkg
  ACCESSIBLE BY (a_proc, another_proc) AS
  FUNCTION a_func ( p_id NUMBER )
    RETURN NUMBER;
END;

-- create accessible package body (will fail)
CREATE OR REPLACE PACKAGE BODY a_pkg
--  ACCESSIBLE BY (a_proc, another_proc)
  AS
  FUNCTION a_func ( p_id NUMBER )
    RETURN NUMBER AS
  BEGIN
    RETURN(p_id * 2);
  END;
END;

-- try to set function in package as accessible (will fail)
CREATE OR REPLACE PACKAGE a_pkg AS
  FUNCTION a_func ( p_id NUMBER )
    RETURN NUMBER
  ACCESSIBLE BY (a_proc, another_proc);
END;




