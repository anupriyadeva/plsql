SET SQLFORMAT ANSICONSOLE
SET PAGES 300
SET LINES 30000

SHO USER

CREATE TABLE demo
( col1 NUMBER )

CREATE OR REPLACE FUNCTION get_cols ( p_table VARCHAR2 )
                  RETURN VARCHAR2
                  AUTHID CURRENT_USER IS
  v_ret_val VARCHAR2(100);
BEGIN
  FOR x IN ( SELECT column_name
               FROM user_tab_columns
              WHERE table_name = p_table ) LOOP
    v_ret_val := v_ret_val || ':' || x.column_name;
  END LOOP;
  RETURN v_ret_val;
END;

CREATE OR REPLACE VIEW tabs_and_cols
          BEQUEATH CURRENT_USER AS
SELECT table_name,
       get_cols(table_name) cols
  FROM user_tables
  
SELECT *
  FROM tabs_and_cols
  
GRANT SELECT ON tabs_and_cols TO drh2