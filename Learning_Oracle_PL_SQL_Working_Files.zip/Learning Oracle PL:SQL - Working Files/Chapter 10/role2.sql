-- run as user drh2
BEGIN
  drh.show_animal(1);
END;
