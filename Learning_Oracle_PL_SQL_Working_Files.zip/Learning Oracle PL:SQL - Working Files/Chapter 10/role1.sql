SET SQLFORMAT ANSICONSOLE

CREATE TABLE animal
( animal_id NUMBER,
  animal_name VARCHAR2(30));
  
INSERT INTO animal
VALUES(1,'Panda');

INSERT INTO animal
VALUES(2,'Zebra');

COMMIT;

-- procedure with authid current_user that accessses
-- local (definers) table has all of the definers privileges
-- but what if that is too much?
CREATE OR REPLACE PROCEDURE show_animal ( p_id NUMBER )
                  AUTHID CURRENT_USER IS
  v_animal animal%ROWTYPE;
BEGIN
   SELECT *
     INTO v_animal
    FROM drh.animal
   WHERE animal_id = p_id;
  DBMS_OUTPUT.PUT_LINE(v_animal.animal_name);
END;

-- grant execute on the privilege to other users
GRANT EXECUTE ON show_animal TO drh2

-- create a role with only the desired privileges
CREATE ROLE select_on_animal
GRANT SELECT ON animal TO select_on_animal

-- grant role to currenr user AND the procedure itself!
GRANT select_on_animal TO drh;
GRANT select_on_animal TO PROCEDURE show_animal

-- see what roles have been granted to what code
SELECT *
  FROM all_code_role_privs