DROP ROLE access_to_everything

-- create basic role
CREATE ROLE access_to_everything

-- create role with an access control package
CREATE ROLE access_to_everything IDENTIFIED USING check_rights_pkg

-- check if the current user is:
--   a) signed on with a password
--   b) a certain userid
--   c) signed on from a certain host
-- must be invoker rights
CREATE OR REPLACE FUNCTION check_right_user
                  RETURN BOOLEAN
                  AUTHID CURRENT_USER IS
BEGIN
  IF SYS_CONTEXT('USERENV','AUTHENTICATION_METHOD') = 'PASSWORD' AND
     SYS_CONTEXT('USERENV','CURRENT_USERID') IN ('111') AND
     SYS_CONTEXT('USERENV','HOST') = 'drh-PC' THEN
    RETURN(TRUE);
  ELSE
    RETURN(FALSE);
  END IF;
END;

-- package to maintain role
-- one and only one procedure
-- must be invoker rights
CREATE OR REPLACE PACKAGE check_rights_pkg
         AUTHID CURRENT_USER AS
  PROCEDURE grant_role_if_correct;
END;

CREATE OR REPLACE PACKAGE BODY check_rights_pkg AS
  PROCEDURE grant_role_if_correct IS
  BEGIN
    -- if user satisfies criteria then assigne role
    IF check_right_user THEN
      DBMS_SESSION.SET_ROLE('ACCESS_TO_EVERYTHING');
     END IF;
  END;
END;

-- test in currenr account
BEGIN
  check_rights_pkg.grant_role_if_correct;
END;

-- check active roles in current session
SELECT *
  FROM session_roles

-- grant role to other use
GRANT access_to_everything TO DRH2

-- allow other user to execute package
GRANT EXECUTE ON check_rights_pkg TO drh2
