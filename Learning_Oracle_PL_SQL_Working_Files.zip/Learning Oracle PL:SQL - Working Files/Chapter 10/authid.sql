CREATE TABLE animal
( animal_id NUMBER,
  animal_name VARCHAR2(30));
  
INSERT INTO animal
VALUES(1,'Panda');

INSERT INTO animal
VALUES(2,'Zebra');

COMMIT;

CREATE OR REPLACE PROCEDURE show_animal ( p_id NUMBER )
                  AUTHID CURRENT_USER IS
  v_animal animal%ROWTYPE;
BEGIN
  SELECT *
    INTO v_animal
    FROM animal
   WHERE animal_id = p_id;
  DBMS_OUTPUT.PUT_LINE(v_animal.animal_name);
END;

BEGIN
  show_animal(1);
END;

GRANT EXECUTE ON show_animal TO drh2
