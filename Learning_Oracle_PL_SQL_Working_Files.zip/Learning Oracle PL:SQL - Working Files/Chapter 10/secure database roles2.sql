-- straigh enablement of role
BEGIN
  DBMS_SESSION.SET_ROLE('ACCESS_TO_EVERYTHING');
END;

-- check active roles for current sesssion
SELECT *
  FROM session_roles

-- see if role can be granted
BEGIN
  drh.check_rights_pkg.grant_role_if_correct;
END;

-- verify userid
SELECT SYS_CONTEXT('USERENV','CURRENT_USERID')
  FROM DUAL