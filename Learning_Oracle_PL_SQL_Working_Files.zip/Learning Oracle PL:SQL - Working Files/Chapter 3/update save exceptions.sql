DECLARE

  -- types and variables for updates
  TYPE v_n_t IS TABLE OF NUMBER;
  v_animal_id v_n_t := v_n_t();
  TYPE v_vc2100_t IS TABLE OF VARCHAR2(100);
  v_animal_name v_vc2100_t := v_vc2100_t();

--  e_dml_error EXCEPTION;
--  PRAGMA EXCEPTION_INIT(e_dml_error,-24381);

BEGIN

  -- assemble 3 animal records in memory
  v_animal_id.EXTEND(3);
  v_animal_name.EXTEND(3);
  FOR counter IN 1..3 LOOP
    v_animal_id(counter) := counter;
    v_animal_name(counter) := RPAD(counter,100,counter);
  END LOOP;

  -- bulk insert 3 row into table
--  BEGIN
    FORALL counter IN 1..v_animal_id.COUNT -- SAVE EXCEPTIONS
      UPDATE animal
      SET animal_name = v_animal_name(counter)
      WHERE animal_id = v_animal_id(counter);
--  EXCEPTION
--     WHEN e_dml_error THEN
--       NULL;
--       FOR counter IN 1..SQL%BULK_EXCEPTIONS.COUNT LOOP
--         DBMS_OUTPUT.PUT_LINE('Error ' || SQL%BULK_EXCEPTIONS(counter).ERROR_CODE ||
--                              ' At Element ' || SQL%BULK_EXCEPTIONS(counter).ERROR_INDEX);
--         DBMS_OUTPUT.PUT_LINE('Animal ID Was ' || v_animal_id(SQL%BULK_EXCEPTIONS(counter).ERROR_INDEX));
--       END LOOP;
--  END;

END;
