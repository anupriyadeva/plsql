SELECT *
  FROM animal

-- delete returning values from single row deletes
DECLARE
  v_animal_id   NUMBER;
  v_animal_name VARCHAR2(30);
BEGIN
  FOR counter IN 1..3 LOOP
    DELETE animal
    WHERE animal_id = counter
      RETURNING animal_id, animal_name
           INTO v_animal_id, v_animal_name;
      DBMS_OUTPUT.PUT_LINE('Deleted '  ||
                           v_animal_id || ' ' ||
                           v_animal_name);
  END LOOP;
END;

-- delete returning values from multiple row deletes
DECLARE
  TYPE v_animal_t IS TABLE OF VARCHAR2(30);
  v_animal_name v_animal_t := v_animal_t();
  TYPE v_n_t IS TABLE OF NUMBER;
  v_animal_id v_n_t := v_n_t();
BEGIN
  FOR counter IN 1..3 LOOP
    DELETE animal
      RETURNING animal_id, animal_name
      BULK COLLECT  INTO v_animal_id, v_animal_name;
      DBMS_OUTPUT.PUT_LINE(v_animal_id.COUNT || ' Records Deleted');
  END LOOP;
END;

-- delete bulk values
DECLARE
  TYPE v_animal_t IS TABLE OF animal%ROWTYPE;
  v_animal v_animal_t := v_animal_t();
  TYPE v_n_t IS TABLE OF NUMBER;
  v_id v_n_t := v_n_t();
BEGIN
  v_animal.EXTEND(2);
  v_animal(1).animal_id := 1;
  v_animal(1).animal_name := 'Zebra';
  v_animal(2).animal_id := 2;
  v_animal(2).animal_name := 'Panda';
  FORALL counter IN 1..2
    DELETE animal
    WHERE animal_id = v_animal(counter).animal_id
    RETURNING animal_id
    BULK COLLECT INTO v_id;
  DBMS_OUTPUT.PUT_LINE(v_id.COUNT || ' Records Deleted');
END;
