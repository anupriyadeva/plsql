SELECT *
  FROM animal

DECLARE
  CURSOR curs_get_animal IS
  SELECT *
    FROM animal;
  v_animal_rec animal%ROWTYPE;
  TYPE v_animal_t IS TABLE OF animal%ROWTYPE;
  v_animal_table v_animal_t := v_animal_t();
BEGIN

  OPEN curs_get_animal;
  -- get records from DB one by one
  LOOP
    FETCH curs_get_animal INTO v_animal_rec;
    EXIT WHEN curs_get_animal%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('Row ' || curs_get_animal%ROWCOUNT);
  END LOOP;
  CLOSE curs_get_animal;

  -- get all records at once
  OPEN curs_get_animal;
  FETCH curs_get_animal
    BULK COLLECT INTO v_animal_table;
  CLOSE curs_get_animal;

  DBMS_OUTPUT.PUT_LINE('Bulk Count ' || v_animal_table.COUNT);
  DBMS_OUTPUT.PUT_LINE('Bulk First ' || v_animal_table.FIRST);
  DBMS_OUTPUT.PUT_LINE('Bulk Last  ' || v_animal_table.LAST);
  FOR counter IN 1..v_animal_table.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE('Bulk ' || counter || ' ' || v_animal_table(counter).animal_name);
  END LOOP;

END;

-- query single columns instead of rows
DECLARE
  CURSOR curs_get_animal IS
  SELECT *
    FROM animal;
  TYPE v_n_t IS TABLE OF NUMBER;
  v_animal_id v_n_t := v_n_t();
  TYPE v_vc2_t IS TABLE OF VARCHAR2(30);
  v_animal_name v_vc2_t := v_vc2_t();
BEGIN
  -- get all records at once
  OPEN curs_get_animal;
  FETCH curs_get_animal
    BULK COLLECT INTO v_animal_id,
                      v_animal_name;
  CLOSE curs_get_animal;

  FOR counter IN 1..v_animal_id.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE('Bulk ' || counter   || ' ' || 
                         v_animal_id(counter) || ' ' ||
                         v_animal_name(counter));
  END LOOP;

END;

-- limit number of records retrieved
DECLARE
  CURSOR curs_get_animal IS
  SELECT *
    FROM animal;
  TYPE v_n_t IS TABLE OF NUMBER;
  v_animal_id v_n_t := v_n_t();
  TYPE v_vc2_t IS TABLE OF VARCHAR2(30);
  v_animal_name v_vc2_t := v_vc2_t();
BEGIN

  OPEN curs_get_animal;

  -- for all records in table...
  LOOP
    -- get 2 records at a time
    FETCH curs_get_animal
    BULK COLLECT INTO v_animal_id,
                      v_animal_name LIMIT 2;

    EXIT WHEN v_animal_id.COUNT = 0;

    -- display retrieved records
    FOR counter IN 1..v_animal_id.COUNT LOOP
      DBMS_OUTPUT.PUT_LINE('Bulk   ' || counter   || ' ' || 
                           'Cursor ' || curs_get_animal%ROWCOUNT || ' ' ||
                           v_animal_id(counter) || ' ' ||
                           v_animal_name(counter));
    END LOOP;

  END LOOP;  -- all records in table

  CLOSE curs_get_animal;

END;
