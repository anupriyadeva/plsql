-- query of animals and their stripes
SELECT *
  FROM animal         a,
       animal_stripes ast
 WHERE a.animal_id = ast.animal_id (+)
 ORDER BY a.animal_id

-- nested cursor demonstration
DECLARE
  CURSOR get_animal IS
  SELECT animal_id,
         animal_name,
         CURSOR ( SELECT stripe_colour
                    FROM animal_stripes
                   WHERE animal_id = animal.animal_id )
    FROM animal;
  v_animal_id    NUMBER;
  v_animal_name  VARCHAR2(30);
  v_stripes_curs SYS_REFCURSOR;
  v_colour       VARCHAR2(30);
BEGIN
  OPEN get_animal;
  -- fetch values from animal table AND a cursor
  -- to get its colour records
  FETCH get_animal INTO v_animal_id,
                        v_animal_name,
                        v_stripes_curs;
  DBMS_OUTPUT.PUT_LINE(v_animal_name);
  -- loop through the cursor for colours
  LOOP
    FETCH v_stripes_curs INTO v_colour;
    EXIT WHEN v_stripes_curs%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('- ' || v_colour);
  END LOOP;
  CLOSE get_animal;
END;

-- nested cursor behaves as all other cursors
DECLARE
  CURSOR get_animal IS
  SELECT CURSOR ( SELECT stripe_colour
                    FROM animal_stripes
                   WHERE animal_id = animal.animal_id )
    FROM animal;
  v_stripes_curs SYS_REFCURSOR;
  v_colour       VARCHAR2(30);
BEGIN
  OPEN get_animal;
  FETCH get_animal INTO v_stripes_curs;
  FOR counter IN 1..3 LOOP
    FETCH v_stripes_curs INTO v_colour;
    DBMS_OUTPUT.PUT_LINE('Rowcount = ' || v_stripes_curs%ROWCOUNT);
    IF v_stripes_curs%FOUND THEN
      DBMS_OUTPUT.PUT_LINE('Found One');
    END IF;
    IF v_stripes_curs%NOTFOUND THEN
      DBMS_OUTPUT.PUT_LINE('Did Not Find One');
    END IF;
    DBMS_OUTPUT.PUT_LINE('Colour = ' || v_colour);
  END LOOP;
  CLOSE get_animal;
END;

-- nested cursors can be passed as parameters just like all other ref cursors
CREATE OR REPLACE PROCEDURE process_stripes ( p_curs SYS_REFCURSOR ) IS
  v_colour VARCHAR2(30);
BEGIN
  LOOP
    FETCH p_curs INTO v_colour;
    EXIT WHEN p_curs%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('- ' || v_colour);
  END LOOP;
END;

-- nested cursors can be passed as parameters just like all other ref cursors
DECLARE
  CURSOR get_animal IS
  SELECT CURSOR ( SELECT stripe_colour
                    FROM animal_stripes
                   WHERE animal_id = animal.animal_id )
    FROM animal;
  v_stripes_curs SYS_REFCURSOR;
  v_colour       VARCHAR2(30);
BEGIN
  OPEN get_animal;
  FETCH get_animal INTO v_stripes_curs;
  process_stripes(v_stripes_curs);
  CLOSE get_animal;
END;
