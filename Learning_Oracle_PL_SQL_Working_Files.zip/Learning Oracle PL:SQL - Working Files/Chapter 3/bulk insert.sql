SELECT *
  FROM animal;

DECLARE

  -- rowtype variable for animal table
  TYPE v_animal_t IS TABLE OF animal%ROWTYPE;
  v_animal v_animal_t := v_animal_t();

  -- column type variables for animal table
  TYPE v_n_t IS TABLE OF NUMBER;
  v_id v_n_t := v_n_t();
  TYPE v_vc230_t IS TABLE OF VARCHAR2(30);
  v_name v_vc230_t := v_vc230_t();

  -- sequential ID 
  v_next_id NUMBER := 0;

BEGIN

  -- assemble 3 animal records in memory
  v_animal.EXTEND(3);
  FOR counter IN 1..3 LOOP
    v_next_id := v_next_id + 1;
    v_animal(counter).animal_id := v_next_id;
    v_animal(counter).animal_name := 'Animal ' || v_next_id;
  END LOOP;

  -- bulk insert 3 row into table
  FORALL counter IN 1..v_animal.COUNT
    INSERT INTO animal
    VALUES v_animal(counter);

  -- assemble 3 animal record.columns in memory
  v_id.EXTEND(3);
  v_name.EXTEND(3);
  FOR counter IN 1..3 LOOP
    v_next_id := v_next_id + 1;
    v_id(counter) := v_next_id;
    v_name(counter) := 'Animal ' || v_next_id;
  END LOOP;

  -- bulk insert 3 row into table
  FORALL counter IN 1..v_id.COUNT
    INSERT INTO animal
    VALUES(v_id(counter),
           v_name(counter));

END;

SELECT *
  FROM animal
ORDER BY animal_id;

ROLLBACK;

-- bulk insert with row count
DECLARE

  -- rowtype variable for animal table
  TYPE v_animal_t IS TABLE OF animal%ROWTYPE;
  v_animal v_animal_t := v_animal_t();

  -- sequential ID 
  v_next_id NUMBER := 0;

BEGIN

  -- assemble 3 animal records in memory
  v_animal.EXTEND(3);
  FOR counter IN 1..3 LOOP
    v_next_id := v_next_id + 1;
    v_animal(counter).animal_id := v_next_id;
    v_animal(counter).animal_name := 'Animal ' || v_next_id;
  END LOOP;

  -- bulk insert 3 row into table
  FORALL counter IN 1..v_animal.COUNT
    INSERT INTO animal
    VALUES v_animal(counter);

  -- see how many rows were actually created
  FOR counter IN 1..v_animal.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE('Element ' || counter || ' ' || SQL%BULK_ROWCOUNT(counter));
  END LOOP;

END;
