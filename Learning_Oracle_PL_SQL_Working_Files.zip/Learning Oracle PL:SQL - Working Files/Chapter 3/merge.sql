DROP TABLE animal;
DROP TABLE other_animal;

CREATE TABLE animal
( animal_id   NUMBER NOT NULL PRIMARY KEY,
  animal_name VARCHAR2(30));

CREATE TABLE other_animal
( animal_id   NUMBER NOT NULL PRIMARY KEY,
  animal_name VARCHAR2(30));

INSERT INTO other_animal VALUES(1,'Zebra');
INSERT INTO other_animal VALUES(2,'Panda');

COMMIT;

-- row by row update/insert
BEGIN
  FOR v_animal IN ( SELECT *
                      FROM other_animal ) LOOP

    UPDATE animal a
    SET animal_name = v_animal.animal_name
    WHERE animal_id = v_animal.animal_id;

    IF SQL%ROWCOUNT > 0 THEN
      DBMS_OUTPUT.PUT_LINE('Updated');
    ELSE
      INSERT INTO animal
      VALUES(v_animal.animal_id,
             v_animal.animal_name);
      DBMS_OUTPUT.PUT_LINE('Inserted');
    END IF;

  END LOOP;
END;

-- row by row insert/update
BEGIN
  FOR v_animal IN ( SELECT *
                      FROM other_animal ) LOOP

    BEGIN
      INSERT INTO animal
      VALUES(v_animal.animal_id,
             v_animal.animal_name);
      DBMS_OUTPUT.PUT_LINE('Inserted');
    EXCEPTION
       WHEN DUP_VAL_ON_INDEX THEN
       UPDATE animal a
       SET animal_name = v_animal.animal_name
       WHERE animal_id = v_animal.animal_id;
       DBMS_OUTPUT.PUT_LINE('Updated');
    END;

  END LOOP;
END;

ROLLBACK;

-- bulk fetch update/insert
DECLARE

  TYPE v_n_t IS TABLE OF NUMBER;
  v_other_id v_n_t := v_n_t();
  TYPE v_vc230_t IS TABLE OF VARCHAR2(30);
  v_other_name v_vc230_t := v_vc230_t();

BEGIN

  SELECT animal_id,
         animal_name
  BULK COLLECT INTO v_other_id,
                    v_other_name
    FROM other_animal;

  FORALL counter IN 1..v_other_id.COUNT
    UPDATE animal
    SET animal_name = v_other_name(counter)
    WHERE animal_id = v_other_id(counter);

  FOR counter IN 1..v_other_id.COUNT LOOP
    IF SQL%BULK_ROWCOUNT(counter) > 0 THEN
      DBMS_OUTPUT.PUT_LINE('Updated Row ' || counter);
      v_other_id.DELETE(counter);
      v_other_name.DELETE(counter);
    ELSE
      DBMS_OUTPUT.PUT_LINE('Inserted Row ' || counter);
    END IF;
  END LOOP;

  FORALL counter IN INDICES OF v_other_id
    INSERT INTO animal
    VALUES(v_other_id(counter),
           v_other_name(counter));

END;

ROLLBACK;

BEGIN
  -- specify merge destination
  MERGE INTO animal a
  -- specify merge source
  USING other_animal oa
    -- specify matching key (unique value)
    ON (a.animal_id = oa.animal_id)
  -- specify what to do when match found
  WHEN MATCHED THEN
    -- when match found update the matching record
    UPDATE SET a.animal_name = oa.animal_name
    -- optional delete on the destination
    DELETE WHERE MOD(animal_id,2) = 0
  -- specify what to do when no match found
  WHEN NOT MATCHED THEN
    -- when match not found then insert the record
    INSERT (animal_id, animal_name)
    VALUES (oa.animal_id, oa.animal_name);
END;

SELECT *
  FROM animal;

SELECT *
  FROM other_animal;
