-- SQL Query - in this case the SQL Developer
-- environment takes care of accepting and displaying
-- the returned values
SELECT *
  FROM animal
  
-- When writing PL/SQL we have to control where the queried
-- values are stored and if required where they are displayed
DECLARE
  CURSOR curs_get_animal IS
  SELECT *
    FROM animal;
  v_animal animal%ROWTYPE;
BEGIN
  OPEN curs_get_animal;
  LOOP
    FETCH curs_get_animal INTO v_animal;
    EXIT WHEN curs_get_animal%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE(v_animal.animal_id || ' ' ||
                         v_animal.animal_name);
  END LOOP;
  CLOSE curs_get_animal;
END;

-- When writing PL/SQL we have to control where the queried
-- values are stored and if required where they are displayed
-- and we have to make sure the input parameter is used
CREATE OR REPLACE PROCEDURE show_animal ( p_id NUMBER ) IS
  CURSOR curs_get_animal ( cp_id NUMBER ) IS
  SELECT *
    FROM animal
   WHERE animal_id = cp_id;
  v_animal animal%ROWTYPE;
BEGIN
  OPEN curs_get_animal(p_id);
  LOOP
    FETCH curs_get_animal INTO v_animal;
    EXIT WHEN curs_get_animal%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE(v_animal.animal_id || ' ' ||
                         v_animal.animal_name);
  END LOOP;
  CLOSE curs_get_animal;
END;

BEGIN
  show_animal(1);
END;
