SELECT *
  FROM animal
ORDER BY animal_id;

-- basic insert of hardcoded values
-- SQL in PLSQL
BEGIN
  INSERT INTO animal
  VALUES(5,'Crocodile');
END;

-- basic insert with error handling
BEGIN
  INSERT INTO animal
  VALUES(5,'Crocodile');
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    DBMS_OUTPUT.PUT_LINE('ID 5 Already Exists');
END;

-- basic insert with error handling and
-- showing success
BEGIN
  INSERT INTO animal
  VALUES(6,'Deer');
  DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT || ' Record Created');
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    DBMS_OUTPUT.PUT_LINE('ID 6 Already Exists');
END;

-- insert rowtype
DECLARE
  v_animal animal%ROWTYPE;
BEGIN
  v_animal.animal_id := 7;
  v_animal.animal_name := 'Bear';
  INSERT INTO animal
  VALUES v_animal;
  DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT || ' Record Created');
END;
