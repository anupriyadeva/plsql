SELECT *
  FROM animal
ORDER BY animal_id;

UPDATE animal
SET animal_name = 'Hippo'
WHERE animal_id = 2;

-- basic update with hardcoded values
BEGIN
  UPDATE animal
  SET animal_name = 'Hippo'
  WHERE animal_id = 2;
END;

-- update with rowcount displayed
BEGIN
  UPDATE animal
  SET animal_name = 'Hippo'
  WHERE animal_id = 2;
  DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT || ' Records Updated');
END;

-- update with error handler
--DECLARE
--  e_too_big EXCEPTION;
--  PRAGMA EXCEPTION_INIT(e_too_big,-12899);
BEGIN
  UPDATE animal
  SET animal_name = 'Hipppppppppppppppppppppoooooooooooo';
--EXCEPTION
--  WHEN e_too_big THEN
--    DBMS_OUTPUT.PUT_LINE('Name Is Too Long');
END;

-- update rowtype
DECLARE
  v_animal animal%ROWTYPE;
BEGIN
  v_animal.animal_id := 2;
  v_animal.animal_name := 'Panda';
  UPDATE animal
  SET animal_name = v_animal.animal_name
  WHERE animal_id = v_animal.animal_id;
  DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT || ' Record Updated');
END;
