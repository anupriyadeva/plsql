DECLARE

  -- rowtype variable for animal table
  TYPE v_animal_t IS TABLE OF animal%ROWTYPE;
  v_animal v_animal_t := v_animal_t();

  -- sequential ID 
  v_next_id NUMBER := 0;
  
  e_dml_error EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_dml_error,-24381);

BEGIN

  -- assemble 3 animal records in memory
  v_animal.EXTEND(3);
  FOR counter IN 1..3 LOOP
    v_next_id := v_next_id + 1;
    v_animal(counter).animal_id := v_next_id;
    v_animal(counter).animal_name := 'Animal ' || v_next_id;
  END LOOP;

  -- bulk insert 3 row into table
  BEGIN
    FORALL counter IN 1..v_animal.COUNT SAVE EXCEPTIONS
      INSERT INTO animal
      VALUES v_animal(counter);
  EXCEPTION
     WHEN e_dml_error THEN
       FOR counter IN 1..SQL%BULK_EXCEPTIONS.COUNT LOOP
         DBMS_OUTPUT.PUT_LINE('Error ' || SQL%BULK_EXCEPTIONS(counter).ERROR_CODE ||
                              ' At Element ' || SQL%BULK_EXCEPTIONS(counter).ERROR_INDEX);
         DBMS_OUTPUT.PUT_LINE('Animal ID Was ' || v_animal(SQL%BULK_EXCEPTIONS(counter).ERROR_INDEX).animal_id);
       END LOOP;
  END;

END;
