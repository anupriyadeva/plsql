-- ref cursor - weak reference
DECLARE
  TYPE v_curs_t IS REF CURSOR;
  v_curs v_curs_t;
  v_animal animal%ROWTYPE;
BEGIN
  -- open fetch and close with whole record
  OPEN v_curs FOR SELECT * FROM animal;
  FETCH v_curs INTO v_animal;
  CLOSE v_curs;
  -- open fetch and close with single column
  OPEN v_curs FOR SELECT animal_id FROM animal;
  FETCH v_curs INTO v_animal.animal_id;
  CLOSE v_curs;
END;

-- ref cursor - strong reference
DECLARE
  TYPE v_curs_t IS REF CURSOR RETURN animal%ROWTYPE;
  v_curs v_curs_t;
  v_animal animal%ROWTYPE;
BEGIN
  -- open fetch and close with whole record
  OPEN v_curs FOR SELECT * FROM animal;
  FETCH v_curs INTO v_animal;
  CLOSE v_curs;
  -- open fetch and close with single column
  OPEN v_curs FOR SELECT animal_id FROM animal;
  FETCH v_curs INTO v_animal.animal_id;
  CLOSE v_curs;
END;

-- ref cursor passed as argument to procedure
CREATE OR REPLACE PROCEDURE abc ( p_curs SYS_REFCURSOR ) IS
  v_animal_rec animal%ROWTYPE;
BEGIN
  LOOP
    FETCH p_curs INTO v_animal_rec;
    EXIT WHEN p_curs%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE(v_animal_rec.animal_name);
  END LOOP;
END;

-- define cursor an pass it to procedure
DECLARE
  TYPE v_curs_t IS REF CURSOR;
  v_curs v_curs_t;
BEGIN
  OPEN v_curs FOR 'SELECT * FROM animal';
  abc(v_curs);
  CLOSE v_curs;
END;

-- ref cursor with parameter
DECLARE
  TYPE v_curs_t IS REF CURSOR;
  v_curs v_curs_t;
  v_animal_rec animal%ROWTYPE;
BEGIN
  OPEN v_curs FOR 'SELECT * FROM animal WHERE animal_id = :1'
    USING 3;
  FETCH v_curs INTO v_animal_rec;
  DBMS_OUTPUT.PUT_LINE(v_animal_rec.animal_id);
  CLOSE v_curs;
END;
