DECLARE

  -- types and variables for deletes
  TYPE v_vc21_t IS TABLE OF VARCHAR2(1);
  v_animal_id v_vc21_t := v_vc21_t();

--  e_dml_error EXCEPTION;
--  PRAGMA EXCEPTION_INIT(e_dml_error,-24381);

BEGIN

  -- assemble 3 animal records in memory
  v_animal_id.EXTEND(3);
  FOR counter IN 1..3 LOOP
    v_animal_id(counter) := counter;
  END LOOP;

  -- set alphanumeric ID to force error
  v_animal_id(3) := 'A';

  -- bulk delete 3 row from table
--  BEGIN
    FORALL counter IN 1..v_animal_id.COUNT -- SAVE EXCEPTIONS
      DELETE animal
      WHERE animal_id = v_animal_id(counter);
--  EXCEPTION
--     WHEN e_dml_error THEN
--       NULL;
--       FOR counter IN 1..SQL%BULK_EXCEPTIONS.COUNT LOOP
--         DBMS_OUTPUT.PUT_LINE('Error ' || SQL%BULK_EXCEPTIONS(counter).ERROR_CODE ||
--                              ' At Element ' || SQL%BULK_EXCEPTIONS(counter).ERROR_INDEX);
--         DBMS_OUTPUT.PUT_LINE('Animal ID Was ' || v_animal_id(SQL%BULK_EXCEPTIONS(counter).ERROR_INDEX));
--       END LOOP;
--  END;

END;

/*
ROLLBACK;
*/
