SELECT *
  FROM animal
ORDER BY animal_id;

DELETE animal
WHERE animal_id = 2;

-- basic delete with hardcoded values
BEGIN
  DELETE animal
  WHERE animal_id = 2;
END;

-- delete with rowcount displayed
BEGIN
  DELETE animal
  WHERE animal_id = 2;
  DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT || ' Records Deleted');
END;

-- delete with error handler
--DECLARE
--  e_not_numeric EXCEPTION;
--  PRAGMA EXCEPTION_INIT(e_not_numeric,-1722);
BEGIN
  DELETE animal
  WHERE animal_id = 'ABC';
--EXCEPTION
--  WHEN e_not_numeric THEN
--    DBMS_OUTPUT.PUT_LINE('ID Is Numeric');
END;

-- delete with rowtype
DECLARE
  v_animal animal%ROWTYPE;
BEGIN
  v_animal.animal_id := 2;
  v_animal.animal_name := 'Panda';
  DELETE animal
   WHERE animal_id = v_animal.animal_id;
  DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT || ' Records Deleted');
END;
