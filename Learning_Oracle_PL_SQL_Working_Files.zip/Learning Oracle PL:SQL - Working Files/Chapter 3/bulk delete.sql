SELECT *
  FROM animal;

-- bulk delete of single rows and multiple rows
DECLARE

  -- column type variables for animal table
  TYPE v_n_t IS TABLE OF NUMBER;
  v_id v_n_t := v_n_t();
  TYPE v_vc230_t IS TABLE OF VARCHAR2(30);
  v_name v_vc230_t := v_vc230_t();

BEGIN

  -- assemble 3 animal record.columns in memory
  v_id.EXTEND(3);
  v_name.EXTEND(3);
  FOR counter IN 1..3 LOOP
    v_id(counter) := counter;
    v_name(counter) := 'Animal ' || counter;
  END LOOP;

  -- bulk update 3 row table
  FORALL counter IN 1..v_id.COUNT
    DELETE animal
    WHERE animal_id = v_id(counter);
--    WHERE animal_id >= v_id(counter);

  FOR counter IN 1..v_id.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE('Element ' || counter || ' Deleted ' || SQL%BULK_ROWCOUNT(counter) || ' Row(s)');
  END LOOP;

END;
