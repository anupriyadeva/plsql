SELECT *
  FROM animal

-- insert returning values
DECLARE
  v_animal_id   NUMBER;
  v_animal_name VARCHAR2(30);
BEGIN
  FOR counter IN 1..10 LOOP
    BEGIN
      INSERT INTO animal
      VALUES(counter,'Animal ' || counter)
      RETURNING animal_id, animal_name
           INTO v_animal_id, v_animal_name;
      DBMS_OUTPUT.PUT_LINE('Created '  ||
                           v_animal_id || ' ' ||
                           v_animal_name);
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        NULL;
    END;
  END LOOP;
END;

-- insert bulk values
DECLARE
  TYPE v_animal_t IS TABLE OF animal%ROWTYPE;
  v_animal v_animal_t := v_animal_t();
  TYPE v_n_t IS TABLE OF NUMBER;
  v_id v_n_t := v_n_t();
BEGIN
  v_animal.EXTEND(2);
  v_animal(1).animal_id := 6;
  v_animal(1).animal_name := 'Animal 6';
  v_animal(2).animal_id := 7;
  v_animal(2).animal_name := 'Animal 7';
  FORALL counter IN 1..2
    INSERT INTO animal
    VALUES v_animal(counter)
    RETURNING animal_id
    BULK COLLECT INTO v_id;
  DBMS_OUTPUT.PUT_LINE(v_id.COUNT || ' Records Created');
END;
