-- for loop with an implicit cursor
BEGIN
  FOR v_animal IN ( SELECT *
                      FROM animal ) LOOP
    DBMS_OUTPUT.PUT_LINE(v_animal.animal_name);
    DBMS_OUTPUT.PUT_LINE('Row Count ' || SQL%ROWCOUNT);
  END LOOP;
END;

-- for loop with explicit cursor
DECLARE
  CURSOR v_curs IS
  SELECT *
    FROM animal;
BEGIN
  FOR v_animal IN v_curs LOOP
    DBMS_OUTPUT.PUT_LINE('Row Count ' || v_curs%ROWCOUNT);
  END LOOP;
END;

-- exit loop with explicit cursor
DECLARE
  CURSOR v_curs IS
  SELECT *
    FROM animal;
  v_animal animal%ROWTYPE;
BEGIN
  OPEN v_curs;
  LOOP
    FETCH v_curs INTO v_animal;
    EXIT WHEN v_curs%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('Row Count ' || v_curs%ROWCOUNT);
  END LOOP;
  CLOSE v_curs;
END;
