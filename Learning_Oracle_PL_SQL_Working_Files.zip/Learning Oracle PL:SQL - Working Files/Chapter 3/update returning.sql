SELECT *
  FROM animal

ROLLBACK

-- update returning values from single row updates
DECLARE
  v_animal_id   NUMBER;
  v_animal_name VARCHAR2(30);
BEGIN
  FOR counter IN 1..3 LOOP
    UPDATE animal
    SET animal_name = 'Animal ' || counter
    WHERE animal_id = counter
      RETURNING animal_id, animal_name
           INTO v_animal_id, v_animal_name;
      DBMS_OUTPUT.PUT_LINE('Updates '  ||
                           v_animal_id || ' ' ||
                           v_animal_name);
  END LOOP;
END;

-- update returning values from multiple row updates
DECLARE
  TYPE v_animal_t IS TABLE OF VARCHAR2(30);
  v_animal_name v_animal_t := v_animal_t();
  TYPE v_n_t IS TABLE OF NUMBER;
  v_animal_id v_n_t := v_n_t();
BEGIN
  FOR counter IN 1..3 LOOP
    UPDATE animal
    SET animal_name = 'Animal ' || counter
      RETURNING animal_id, animal_name
      BULK COLLECT  INTO v_animal_id, v_animal_name;
      DBMS_OUTPUT.PUT_LINE(v_animal_id.COUNT || ' Records Updated');
  END LOOP;
END;

-- update bulk values
DECLARE
  TYPE v_animal_t IS TABLE OF animal%ROWTYPE;
  v_animal v_animal_t := v_animal_t();
  TYPE v_n_t IS TABLE OF NUMBER;
  v_id v_n_t := v_n_t();
BEGIN
  v_animal.EXTEND(2);
  v_animal(1).animal_id := 1;
  v_animal(1).animal_name := 'Zebra';
  v_animal(2).animal_id := 2;
  v_animal(2).animal_name := 'Panda';
  FORALL counter IN 1..2
    UPDATE animal
    SET animal_name = v_animal(counter).animal_name
    WHERE animal_id = v_animal(counter).animal_id
    RETURNING animal_id
    BULK COLLECT INTO v_id;
  DBMS_OUTPUT.PUT_LINE(v_id.COUNT || ' Records Updates');
END;
