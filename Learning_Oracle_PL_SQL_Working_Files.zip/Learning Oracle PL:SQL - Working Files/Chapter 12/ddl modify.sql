CREATE TABLE animal ( animal_id NUMBER,

                      animal_name VARCHAR2(30) );



SELECT column_name,

       data_length

  FROM user_tab_columns



BEGIN

  EXECUTE IMMEDIATE '
ALTER TABLE animal
 MODIFY ( animal_name VARCHAR2(300))';

END;



BEGIN

  DBMS_UTILITY.EXEC_DDL_STATEMENT('ALTER TABLE animal MODIFY ( animal_name VARCHAR2(3000))');

END;



DECLARE

  v_curs NUMBER;

  v_ret_val INTEGER;

BEGIN

  v_curs := DBMS_SQL.OPEN_CURSOR;

  DBMS_SQL.PARSE(v_curs,'ALTER TABLE animal MODIFY ( animal_name VARCHAR2(3000))',DBMS_SQL.NATIVE);

  DBMS_SQL.CLOSE_CURSOR(v_curs);

END;



BEGIN

  EXECUTE IMMEDIATE '
ALTER TABLE animal
 MODIFY ( animal_name VARCHAR2(3000000000))';

EXCEPTION

  WHEN ddl_exceptions.e_too_long THEN
    DBMS_OUTPUT.PUT_LINE('That value is too long');

END;



CREATE OR REPLACE PACKAGE ddl_exceptions AS

  e_too_long EXCEPTION;

  PRAGMA EXCEPTION_INIT(e_too_long,-910);

END;
