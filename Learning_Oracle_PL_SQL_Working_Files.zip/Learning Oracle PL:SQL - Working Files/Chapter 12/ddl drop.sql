CREATE TABLE animal
( animal_id   NUMBER NOT NULL PRIMARY KEY,
  animal_name VARCHAR2(30));

-- if only it was this easy...
BEGIN
  DROP TABLE animal;
END;

-- native dynamic SQL
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE animal';
END;

-- DDL procedure
BEGIN
  DBMS_UTILITY.EXEC_DDL_STATEMENT('DROP TABLE animal');
END;

-- DBMS_SQL
DECLARE
  v_curs    NUMBER;
  v_ret_val INTEGER;
BEGIN
  v_curs := DBMS_SQL.OPEN_CURSOR;
  DBMS_SQL.PARSE(v_curs,'DROP TABLE animal',DBMS_SQL.NATIVE);
  DBMS_SQL.CLOSE_CURSOR(v_curs);
END;

CREATE TABLE animal_stripes
( animal_id NUMBER,
  stripe_color VARCHAR2(30) )
  
ALTER TABLE animal_stripes
ADD CONSTRAINT stripe_to_animal
FOREIGN KEY ( animal_id )
REFERENCES animal ( animal_id );

-- procedure to drop tables
CREATE OR REPLACE PROCEDURE drop_table ( p_table VARCHAR2 ) IS
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE ' || p_table;
END;

-- try to drop table in SQL to show error -2449
DROP TABLE animal

BEGIN
  drop_table('ANIMAL');
END;

CREATE OR REPLACE PACKAGE ddl_exceptions AS
  e_ref_by_fk EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_ref_by_fk,-2449);
END;

-- augment procedure to show referenced FK
CREATE OR REPLACE PROCEDURE drop_table ( p_table VARCHAR2 ) IS
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE ' || p_table;
EXCEPTION
  WHEN ddl_exceptions.e_ref_by_fk THEN
    -- get unique and primary key constraints
    FOR cons IN ( SELECT *
                    FROM USER_CONSTRAINTS
                   WHERE TABLE_NAME = p_table
                     AND constraint_type IN ('U','P') ) LOOP
      DBMS_OUTPUT.PUT_LINE(cons.constraint_type || ':' ||
                           cons.constraint_name);
      FOR refc IN ( SELECT *
                      FROM user_constraints
                     WHERE r_constraint_name = cons.constraint_name ) LOOP
        DBMS_OUTPUT.PUT_LINE(refc.constraint_type || ':' ||
                             refc.constraint_name);
      END LOOP;
    END LOOP;
END;
