-- if only it was this easy...
BEGIN
  CREATE TABLE animal ( animal_id NUMBER,
                        animal_name VARCHAR2(30) );
END;

CREATE OR REPLACE PACKAGE excptn AS
  e_already_exist EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_already_exist,-955);
  e_does_not_exist EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_does_not_exist,-942);
END;

BEGIN
  EXECUTE IMMEDIATE '
  CREATE TABLE animal ( animal_id NUMBER,
                        animal_name VARCHAR2(30) )';
EXCEPTION
  WHEN excptn.e_already_exist THEN
    NULL;
END;

BEGIN
  DBMS_UTILITY.EXEC_DDL_STATEMENT('CREATE UNIQUE INDEX animal_ix ON animal ( animal_id )');
EXCEPTION
  WHEN excptn.e_already_exist THEN
    NULL;
  WHEN excptn.e_does_not_exist THEN
    NULL;
END;

DECLARE
  v_curs    NUMBER;
  v_ret_val INTEGER;
BEGIN
  v_curs := DBMS_SQL.OPEN_CURSOR;
  DBMS_SQL.PARSE(v_curs,'DROP TABLE animal',DBMS_SQL.NATIVE);
  DBMS_SQL.CLOSE_CURSOR(v_curs);
EXCEPTION
  WHEN excptn.e_does_not_exist THEN
    NULL;
END;
