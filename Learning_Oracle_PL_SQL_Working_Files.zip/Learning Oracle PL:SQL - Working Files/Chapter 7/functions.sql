-- simple function that doubles a give number
CREATE OR REPLACE FUNCTION double_number ( p_number NUMBER )
                  RETURN NUMBER IS
BEGIN
  RETURN(p_number * 2);
END;

BEGIN
  DBMS_OUTPUT.PUT_LINE(double_number(10));
END;

-- function without a return statement
CREATE OR REPLACE FUNCTION no_return
                  RETURN NUMBER IS
BEGIN
  NULL;
END;

BEGIN
  DBMS_OUTPUT.PUT_LINE(no_return);
END;

CREATE OR REPLACE TYPE v_number_t AS TABLE OF NUMBER;
/

-- return a pl/sql table
CREATE OR REPLACE FUNCTION return_table ( p_id NUMBER )
                  RETURN v_number_t AS
  v_ret_val v_number_t := v_number_t();
BEGIN
  v_ret_val.EXTEND(p_id);
  FOR counter IN 1..p_id LOOP
    v_ret_val(counter) := counter;
  END LOOP;
  RETURN(v_ret_val);
END;

DECLARE
  v_t v_number_t := v_number_t();
BEGIN
  v_t := return_table(3);
  FOR counter IN 1..v_t.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE(v_t(counter));
  END LOOP;
END;

-- declare function as deterministic
CREATE OR REPLACE FUNCTION return_table ( p_id NUMBER )
                  RETURN v_number_t
                  DETERMINISTIC AS
  v_ret_val v_number_t := v_number_t();
BEGIN
  v_ret_val.EXTEND(p_id);
  FOR counter IN 1..p_id LOOP
    v_ret_val(counter) := counter;
  END LOOP;
  RETURN(v_ret_val);
END;

-- function the returns ref cursor
CREATE OR REPLACE FUNCTION return_cursor
                  RETURN SYS_REFCURSOR IS
  v_curs SYS_REFCURSOR;
BEGIN
  OPEN v_curs FOR 'SELECT * FROM animal';
  RETURN(v_curs);
END;

DECLARE
  v_curs SYS_REFCURSOR;
  v_animal animal%ROWTYPE;
BEGIN
  v_curs := return_cursor;
  LOOP
    FETCH v_curs INTO v_animal;
    EXIT WHEN v_curs%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE(v_animal.animal_name);
  END LOOP;
END;
