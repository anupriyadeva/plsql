SELECT *
  FROM animal
  
CREATE OR REPLACE FUNCTION count_animals
                  RETURN NUMBER
                  RESULT_CACHE IS
  v_ret_val NUMBER;
BEGIN
  SELECT COUNT(*)
    INTO v_ret_val
    FROM animal;
  RETURN(v_ret_val);
END;

BEGIN
  DBMS_OUTPUT.PUT_LINE(count_animals);
END;

SELECT name,
       type,
       invalidations
  FROM V$RESULT_CACHE_OBJECTS
 WHERE name LIKE '%ANIMAL%'

SELECT name,
       value
  FROM V$RESULT_CACHE_STATISTICS
 WHERE name = 'Find Count'
 
INSERT INTO animal
VALUES(3,'Tiger');

COMMIT