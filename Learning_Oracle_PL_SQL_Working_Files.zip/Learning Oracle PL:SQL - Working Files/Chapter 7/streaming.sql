SET SQLFORMAT ANSICONSOLE
SET LINESIZE 132
SET PAGESIZE 300

DROP TABLE bunch_of_numbers

CREATE TABLE bunch_of_numbers
( col1 NUMBER UNIQUE );

BEGIN
  FOR counter IN 65..75 LOOP
    INSERT INTO bunch_of_numbers
    VALUES(counter);
  END LOOP;
END;

CREATE OR REPLACE TYPE v_number_t AS TABLE OF NUMBER;
/

CREATE OR REPLACE PACKAGE cursors AS
  TYPE number_cursor IS REF CURSOR RETURN bunch_of_numbers%ROWTYPE;
END;

CREATE OR REPLACE FUNCTION return_table ( p_curs cursors.number_cursor )
                  RETURN v_number_t
                  PIPELINED
                  PARALLEL_ENABLE ( PARTITION p_curs BY RANGE(col1) )
                  ORDER p_curs BY (col1) AS
  v_number NUMBER;
BEGIN
  LOOP
    FETCH p_curs INTO v_number;
    EXIT WHEN p_curs%NOTFOUND;
    PIPE ROW(v_number);
  END LOOP;
END;

SELECT *
  FROM TABLE( return_table ( CURSOR( SELECT *
                                       FROM bunch_of_numbers )))

CREATE OR REPLACE TYPE v_vc2_10_t AS TABLE OF VARCHAR2(10);
/

CREATE OR REPLACE FUNCTION return_chr ( p_curs cursors.number_cursor )
                  RETURN v_vc2_10_t
                  PIPELINED AS
  v_vc2_10 VARCHAR2(10);
BEGIN
  LOOP
    FETCH p_curs INTO v_vc2_10;
    EXIT WHEN p_curs%NOTFOUND;
    PIPE ROW(CHR(v_vc2_10));
  END LOOP;
END;

SELECT *
  FROM TABLE(return_chr(CURSOR(
SELECT *
  FROM TABLE( return_table ( CURSOR( SELECT *
                                       FROM bunch_of_numbers )))
)))
