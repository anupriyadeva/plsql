SET SQLFORMAT ANSICONSOLE
SET LINESIZE 132
SET PAGESIZE 300

DROP TABLE bunch_of_numbers

CREATE TABLE bunch_of_numbers
( col1 NUMBER UNIQUE );

BEGIN
  FOR counter IN 1..10 LOOP
    INSERT INTO bunch_of_numbers
    VALUES(counter);
  END LOOP;
END;

CREATE OR REPLACE TYPE v_number_t AS TABLE OF NUMBER;
/

-- return a pl/sql table
CREATE OR REPLACE FUNCTION return_table ( p_curs SYS_REFCURSOR )
                  RETURN v_number_t
                  PIPELINED
                  PARALLEL_ENABLE ( PARTITION p_curs BY ANY) AS
  v_number NUMBER;
BEGIN
  LOOP
    FETCH p_curs INTO v_number;
    EXIT WHEN p_curs%NOTFOUND;
    PIPE ROW(v_number);
  END LOOP;
END;

SELECT *
  FROM TABLE(return_table(CURSOR(SELECT *
                                   FROM bunch_of_numbers)))

CREATE OR REPLACE FUNCTION return_table ( p_curs SYS_REFCURSOR )
-- CREATE OR REPLACE FUNCTION return_table ( p_curs cursors.number_cursor )
                  RETURN v_number_t
                  PIPELINED
--                  PARALLEL_ENABLE ( PARTITION p_curs BY RANGE(col1) )
                  PARALLEL_ENABLE ( PARTITION p_curs BY HASH(col1) )
--                  CLUSTER p_curs BY (col1) AS
                  ORDER p_curs BY (col1) AS
  v_number NUMBER;
BEGIN
  LOOP
    FETCH p_curs INTO v_number;
    EXIT WHEN p_curs%NOTFOUND;
    PIPE ROW(v_number);
  END LOOP;
END;

CREATE OR REPLACE PACKAGE cursors AS
  TYPE number_cursor IS REF CURSOR RETURN bunch_of_numbers%ROWTYPE;
END;
