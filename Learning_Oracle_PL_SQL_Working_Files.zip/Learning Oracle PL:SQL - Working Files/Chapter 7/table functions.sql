CREATE OR REPLACE TYPE v_number_t AS TABLE OF NUMBER;
/

-- return a pl/sql table
CREATE OR REPLACE FUNCTION return_table ( p_id NUMBER )
                  RETURN v_number_t AS
  v_ret_val v_number_t := v_number_t();
BEGIN
  v_ret_val.EXTEND(p_id);
  FOR counter IN 1..p_id LOOP
    v_ret_val(counter) := counter;
  END LOOP;
  RETURN(v_ret_val);
END;
/

-- query the function as if it was a table
SELECT *
  FROM TABLE(return_table(5))
 WHERE column_value = 3

-- query with joins
SELECT *
  FROM TABLE(return_table(5)) a,
       TABLE(return_table(3)) b
 WHERE a.column_value = b.column_value
 
-- create object and table with 2 columns
CREATE OR REPLACE TYPE v_numbers_o AS OBJECT ( positive_number NUMBER,
                                               negative_number NUMBER );
/
CREATE OR REPLACE TYPE v_numbers_t AS TABLE OF v_numbers_o;
/

-- create function to manufacture pairs of numbers
CREATE OR REPLACE FUNCTION return_table ( p_id NUMBER )
                  RETURN v_numbers_t AS
  v_ret_val v_numbers_t := v_numbers_t();
BEGIN
  v_ret_val.EXTEND(p_id);
  FOR counter IN 1..p_id LOOP
    v_ret_val(counter) := v_numbers_o(counter,counter * -1);
  END LOOP;
  RETURN(v_ret_val);
END;

-- query the function as if it were a table
SELECT *
  FROM TABLE(return_table(5))
 WHERE positive_number = 3

CREATE OR REPLACE TYPE animal_o AS OBJECT ( animal_id    NUMBER,
                                            animal_name  VARCHAR2(30),
                                            ascii_animal VARCHAR2(100) );
/
CREATE OR REPLACE TYPE animal_t AS TABLE OF animal_o;
/

-- interaction with db table
CREATE OR REPLACE FUNCTION ascii_animal
                  RETURN animal_t AS
  v_ret_val animal_t := animal_t();
  v_ascii   VARCHAR2(100);
BEGIN
  FOR v_animal IN ( SELECT *
                      FROM animal ) LOOP
    FOR counter IN 1..LENGTH(v_animal.animal_name) LOOP
      v_ascii := v_ascii || ASCII(SUBSTR(v_animal.animal_name,counter,1));
    END LOOP;
    v_ret_val.EXTEND;
    v_ret_val(v_ret_val.LAST) := animal_o(v_animal.animal_id,
                                          v_animal.animal_name,
                                          v_ascii);
  END LOOP;
  RETURN(v_ret_val);
END;

SELECT *
  FROM TABLE(ascii_animal)

-- call a function with no return
CREATE OR REPLACE FUNCTION no_return
                  RETURN v_number_t AS
BEGIN
  NULL;
END;

SELECT *
  FROM TABLE(no_return)

-- raise no data found
CREATE OR REPLACE FUNCTION raise_ndf
                  RETURN v_number_t AS
BEGIN
  RAISE NO_DATA_FOUND;
END;

SELECT *
  FROM TABLE(raise_ndf)

-- raise too many rows
CREATE OR REPLACE FUNCTION raise_too_many
                  RETURN v_number_t AS
BEGIN
  RAISE TOO_MANY_ROWS;
END;

SELECT *
  FROM TABLE(raise_too_many)