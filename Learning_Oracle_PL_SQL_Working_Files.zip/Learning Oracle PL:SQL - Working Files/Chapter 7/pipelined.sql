SET SQLFORMAT ANSICONSOLE
SET LINESIZE 132

CREATE OR REPLACE TYPE v_number_t AS TABLE OF NUMBER;
/

-- return a pl/sql table
CREATE OR REPLACE FUNCTION return_table ( p_id NUMBER )
                  RETURN v_number_t
                  PIPELINED AS
BEGIN
  FOR counter IN 1..p_id LOOP
    PIPE ROW(counter);
  END LOOP;
  RETURN;
END;

SELECT *
  FROM TABLE(return_table(9))
