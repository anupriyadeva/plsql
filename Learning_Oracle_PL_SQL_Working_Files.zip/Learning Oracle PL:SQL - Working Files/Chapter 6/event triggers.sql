SET SQLFORMAT ANSICONSOLE
SET LINESIZE 132

-- create table to hold logon information
CREATE TABLE logon_log
( username        VARCHAR2(30),
  logon_tinestamp TIMESTAMP )

-- create after logon trigger
CREATE OR REPLACE TRIGGER AFTER_LOGON
AFTER LOGON
ON SCHEMA
BEGIN
  INSERT INTO logon_log
  VALUES(ora_login_user,systimestamp);
END;

SELECT *
  FROM logon_log

DISCONNECT
CONNECT drh/drhdrh

-- create table logoff log
CREATE TABLE logoff_log
( username        VARCHAR2(30),
  logon_tinestamp TIMESTAMP )

-- create before logoff trigger
CREATE OR REPLACE TRIGGER BEFORE_LOGOFF
BEFORE LOGOFF
ON SCHEMA
BEGIN
  INSERT INTO logoff_log
  VALUES(ora_login_user,systimestamp);
END;

SELECT *
  FROM logoff_log

DISCONNECT
CONNECT drh/drhdrh

-- table to hold DB startup info
CREATE TABLE startup_log
( startup_timestamp TIMESTAMP );

-- after DB startup trigger  
CREATE OR REPLACE TRIGGER after_startup
AFTER STARTUP
ON DATABASE
BEGIN
  INSERT INTO startup_log
  VALUES(SYSTIMESTAMP);
END;

SELECT *
  FROM startup_log

-- table to hold shutdown information
CREATE TABLE shutdown_log
( shutdown_timestamp TIMESTAMP );

-- before shutdown trigger  
CREATE OR REPLACE TRIGGER before_shutdown
BEFORE SHUTDOWN
ON DATABASE
BEGIN
  INSERT INTO shutdown_log
  VALUES(SYSTIMESTAMP);
END;

SELECT *
  FROM shutdown_log

-- server error trigger
CREATE OR REPLACE TRIGGER after_error
AFTER SERVERERROR
ON SCHEMA
BEGIN

  DBMS_OUTPUT.PUT_LINE('User '  || ora_login_user || ' ' ||
                       'Event ' || ora_sysevent);

  -- output error stack depth
  DBMS_OUTPUT.PUT_LINE('Error Stack Levels = ' || ora_server_error_depth);

  -- for every entry on the error stack...
  FOR ecounter IN 1..ora_server_error_depth LOOP
  
    -- output error code and message at this position on stack
    DBMS_OUTPUT.PUT_LINE(ora_server_error(ecounter) || ' ' ||
                         ora_server_error_msg(ecounter));
    DBMS_OUTPUT.PUT_LINE('Param Count ' || ora_server_error_num_params(ecounter));
  
    -- if this position on stack has parameters then output them
    IF ora_server_error_num_params(ecounter) > 0 THEN

      -- output parameters
      FOR pcounter IN 1..ora_server_error_num_params(ecounter) LOOP
        DBMS_OUTPUT.PUT_LINE('Param ' || pcounter || ' ' || ora_server_error_param(ecounter,pcounter));
      END LOOP;

    END IF;  -- position on stack has params
  
  END LOOP;  -- every entry on the error stack

END;

BEGIN
  RAISE DUP_VAL_ON_INDEX;
END;

CREATE TABLE demo
( col1 NUMBER UNIQUE )
INSERT INTO demo VALUES(1)

CREATE OR REPLACE TRIGGER after_error
AFTER SERVERERROR
ON SCHEMA
BEGIN
  -- check if error was a duplicate value on index
  IF ora_is_servererror(1) THEN
    DBMS_OUTPUT.PUT_LINE('Duplicate Value Attempted');
  END IF;
END;
