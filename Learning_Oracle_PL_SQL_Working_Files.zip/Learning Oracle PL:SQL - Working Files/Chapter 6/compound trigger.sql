SET SQLFORMAT ansiconsole

BEGIN
  FOR x IN ( SELECT trigger_name
               FROM user_triggers ) LOOP
    EXECUTE IMMEDIATE 'DROP TRIGGER ' || x.trigger_name;
  END LOOP;
END;

DELETE animal WHERE animal_id > 2;
DELETE animal WHERE animal_id IS NULL;

CREATE OR REPLACE TRIGGER compound_animal
FOR INSERT ON animal
COMPOUND TRIGGER

  BEFORE STATEMENT IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE('Compound Before Statement');
  END BEFORE STATEMENT;

  BEFORE EACH ROW IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE('Compound Before Row');
  END BEFORE EACH ROW;

  AFTER EACH ROW IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE('Compound After Row');
  END AFTER EACH ROW;

  AFTER STATEMENT IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE('Compound After Statement');
  END AFTER STATEMENT;

END;

INSERT INTO animal
VALUES(88,'Lynx');

SELECT object_type
  FROM user_objects
 WHERE object_name = 'COMPOUND_ANIMAL'

SELECT trigger_name,
       trigger_type
  FROM user_triggers

CREATE OR REPLACE TRIGGER compound_animal
FOR INSERT ON animal
COMPOUND TRIGGER

  v_local_variable NUMBER := 1;

  BEFORE STATEMENT IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE(v_local_variable);
    v_local_variable := v_local_variable + 1;
  END BEFORE STATEMENT;

  BEFORE EACH ROW IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE(v_local_variable);
    v_local_variable := v_local_variable + 1;
  END BEFORE EACH ROW;

  AFTER EACH ROW IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE(v_local_variable);
    v_local_variable := v_local_variable + 1;
  END AFTER EACH ROW;

  AFTER STATEMENT IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE(v_local_variable);
    v_local_variable := v_local_variable + 1;
  END AFTER STATEMENT;

END;

INSERT INTO animal
VALUES(77,'Cheetah');

INSERT INTO animal
VALUES(33,'Whale');