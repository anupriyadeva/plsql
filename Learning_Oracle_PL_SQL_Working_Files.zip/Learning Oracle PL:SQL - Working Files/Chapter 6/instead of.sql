SET SQLFORMAT ANSICONSOLE
SET LINESIZE 132
BEGIN
  FOR x IN ( SELECT *
               FROM user_objects ) LOOP
    EXECUTE IMMEDIATE 'DROP ' || x.object_type || ' ' || x.object_name;
  END LOOP;
END;

CREATE TABLE animal
( animal_id   NUMBER       NOT NULL,
  animal_name VARCHAR2(30) NOT NULL );
  
CREATE TABLE animal_stripes
( animal_id     NUMBER       NOT NULL,
  stripe_id     NUMBER       NOT NULL,
  stripe_colour VARCHAR2(30) NOT NULL );

-- create view to display animal and first 2 stripes
CREATE VIEW animals_with_stripes AS
SELECT animal_name,
       ( SELECT stripe_colour
           FROM animal_stripes
          WHERE animal_id = animal.animal_id
            AND stripe_id = 1 ) AS stripe_one,
       ( SELECT stripe_colour
           FROM animal_stripes
          WHERE animal_id = animal.animal_id
            AND stripe_id = 2 ) AS stripe_two
  FROM animal;

SELECT *
  FROM animals_with_stripes

-- insert an entry for zebra
INSERT INTO animals_with_stripes
VALUES('Zebra','White','Black')

-- create instead of trigger stub
CREATE TRIGGER insert_animal_with_stripes
INSTEAD OF INSERT
ON animals_with_stripes
BEGIN
  NULL;
END;

-- add queries to get next ID values
CREATE OR REPLACE TRIGGER insert_animal_with_stripes
INSTEAD OF INSERT
ON animals_with_stripes
DECLARE
  v_animal_id NUMBER;
  v_stripe_id NUMBER;
BEGIN

  -- use rowcount + 1 for animal id
  SELECT COUNT(*) + 1
    INTO v_animal_id
    FROM animal;
  DBMS_OUTPUT.PUT_LINE('New Animal ID ' || v_animal_id);

  -- use rowcount + 1 for stripe id
  SELECT COUNT(*) + 1
    INTO v_stripe_id
    FROM animal_stripes
   WHERE animal_id = v_animal_id;
  DBMS_OUTPUT.PUT_LINE('New Stripe ID ' || v_stripe_id);

END;

-- add inserts into underlying tables
CREATE OR REPLACE TRIGGER insert_animal_with_stripes
INSTEAD OF INSERT
ON animals_with_stripes
DECLARE
  v_animal_id NUMBER;
  v_stripe_id NUMBER;
BEGIN

  -- use rowcount + 1 for animal id
  SELECT COUNT(*) + 1
    INTO v_animal_id
    FROM animal;
  DBMS_OUTPUT.PUT_LINE('New Animal ID ' || v_animal_id);

  -- create entry in animal table
  INSERT INTO animal
  VALUES(v_animal_id,:NEW.animal_name);

  -- use rowcount + 1 for stripe id
  SELECT COUNT(*) + 1
    INTO v_stripe_id
    FROM animal_stripes
   WHERE animal_id = v_animal_id;
  DBMS_OUTPUT.PUT_LINE('New Stripe ID ' || v_stripe_id);

  -- create first stripe entry
  INSERT INTO animal_stripes
  VALUES(v_animal_id,v_stripe_id,:NEW.stripe_one);

  -- use rowcount + 1 for stripe id
  SELECT COUNT(*) + 1
    INTO v_stripe_id
    FROM animal_stripes
   WHERE animal_id = v_animal_id;
  DBMS_OUTPUT.PUT_LINE('New Stripe ID ' || v_stripe_id);

  -- create second stripe entry
  INSERT INTO animal_stripes
  VALUES(v_animal_id,v_stripe_id,:NEW.stripe_two);

END;

COMMIT;

UPDATE animals_with_stripes
SET stripe_one = 'Red',
    stripe_two = 'Blue'
WHERE animal_name = 'Zebra'

-- create trigger stub for updates
CREATE OR REPLACE TRIGGER update_animal_with_stripes
INSTEAD OF UPDATE
ON animals_with_stripes
BEGIN
  NULL;
END;

SELECT *
  FROM animal_stripes
  
-- create trigger to handle updates of stripe colours
CREATE OR REPLACE TRIGGER update_animal_with_stripes
INSTEAD OF UPDATE
ON animals_with_stripes
BEGIN

  UPDATE animal_stripes
  SET stripe_colour = :NEW.stripe_one
  WHERE animal_id = ( SELECT animal_id
                        FROM animal
                       WHERE animal_name = :NEW.animal_name )
  AND stripe_id = 1;
  DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT);

  UPDATE animal_stripes
  SET stripe_colour = :NEW.stripe_two
  WHERE animal_id = ( SELECT animal_id
                        FROM animal
                       WHERE animal_name = :NEW.animal_name )
  AND stripe_id = 2;
  DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT);

END;

-- create trigger to handle updates of stripe colours...
-- ...but only if the colour actually changed
CREATE OR REPLACE TRIGGER update_animal_with_stripes
INSTEAD OF UPDATE
ON animals_with_stripes
BEGIN

  UPDATE animal_stripes
  SET stripe_colour = :NEW.stripe_one
  WHERE animal_id = ( SELECT animal_id
                        FROM animal
                       WHERE animal_name = :NEW.animal_name )
  AND stripe_id = 1
  AND stripe_colour <> :NEW.stripe_one;
  DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT);

  UPDATE animal_stripes
  SET stripe_colour = :NEW.stripe_two
  WHERE animal_id = ( SELECT animal_id
                        FROM animal
                       WHERE animal_name = :NEW.animal_name )
  AND stripe_id = 2
  AND stripe_colour <> :NEW.stripe_two;
  DBMS_OUTPUT.PUT_LINE('Updated ' || SQL%ROWCOUNT);

END;

-- compare old and new values to see if anything actually changed
CREATE OR REPLACE TRIGGER update_animal_with_stripes
INSTEAD OF UPDATE
ON animals_with_stripes
BEGIN
  IF :NEW.animal_name = :OLD.animal_name THEN
    RAISE_APPLICATION_ERROR(-20000,'Name is already set to ' || :OLD.animal_name);
  END IF;
END;

UPDATE animals_with_stripes
SET animal_name = 'Zebra'

CREATE OR REPLACE TRIGGER delete_animal_with_stripes
INSTEAD OF DELETE
ON animals_with_stripes
DECLARE
  v_animal_id NUMBER;
BEGIN
  DBMS_OUTPUT.PUT_LINE('Looking for ' || :OLD.animal_name);
  SELECT animal_id
    INTO v_animal_id
    FROM animal
   WHERE animal_name = :OLD.animal_name;
  DBMS_OUTPUT.PUT_LINE('Found ' || :OLD.animal_name);  
  DELETE animal_stripes
  WHERE animal_id = v_animal_id;
  DBMS_OUTPUT.PUT_LINE('Deleted ' || SQL%ROWCOUNT || ' Stripes');
  DELETE animal
  WHERE animal_id = v_animal_id;
  DBMS_OUTPUT.PUT_LINE('Deleted ' || SQL%ROWCOUNT || ' Animals');
END;  

-- delete record 
DELETE animals_with_stripes
WHERE animal_name = 'Zebra'

DROP TRIGGER delete_animal_with_stripes

-- create trigger that will fail
CREATE TRIGGER raise_exception
INSTEAD OF INSERT
ON animals_with_stripes
DECLARE
  v_number NUMBER;
BEGIN
  v_number := 'ABC';
END;

INSERT INTO animals_with_stripes
VALUES('Tiger','Black','Yellow');

-- create trigger that will raise no data found
CREATE OR REPLACE TRIGGER raise_exception
INSTEAD OF INSERT
ON animals_with_stripes
DECLARE
  v_number NUMBER;
BEGIN
  SELECT animal_id
    INTO v_number
    FROM animal
   WHERE 1 = 2;
END;

INSERT INTO animals_with_stripes
VALUES('Tiger','Black','Yellow');
