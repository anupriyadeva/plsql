SET SQLFORMAT ANSICONSOLE
SET LINESIZE 132

BEGIN
  FOR x IN ( SELECT trigger_name
               FROM user_triggers ) LOOP
    EXECUTE IMMEDIATE 'DROP TRIGGER ' || x.trigger_name;
  END LOOP;
END;

BEGIN
  FOR x IN ( SELECT object_name
               FROM user_objects
              WHERE object_type = 'PROCEDURE' ) LOOP
    EXECUTE IMMEDIATE 'DROP PROCEDURE ' || x.object_name;
  END LOOP;
END;

BEGIN
  FOR x IN ( SELECT table_name
               FROM user_tables
              WHERE table_name != 'ANIMAL' ) LOOP
    EXECUTE IMMEDIATE 'DROP TABLE ' || x.table_name;
  END LOOP;
END;

SELECT object_name
  FROM user_objects

-- create a trigger to prevent all DDL in the current schema
CREATE OR REPLACE TRIGGER no_ddl
BEFORE DDL
ON SCHEMA
BEGIN
  RAISE_APPLICATION_ERROR(-20000,'No DDL Allowed');
END;

-- try to drop a table
DROP TABLE animal;
DROP TABLE does_not_exist;

-- drop the undroppable trigger
DROP TRIGGER no_ddl;

-- create a triggers to monitor all creates
CREATE OR REPLACE TRIGGER before_create
BEFORE CREATE
ON SCHEMA
BEGIN
  DBMS_OUTPUT.PUT_LINE('You Created A ' || ORA_DICT_OBJ_TYPE ||
                       ' Named '        || ORA_DICT_OBJ_NAME);
END;

-- create table and index
CREATE TABLE abc
( col1 NUMBER );
CREATE INDEX abc_ix ON abc ( col1 );

-- drop the create trigger
DROP TRIGGER before_create

-- create a triggers to track specific DDL events
CREATE OR REPLACE TRIGGER all_ddl
BEFORE DDL
ON SCHEMA
BEGIN
  DBMS_OUTPUT.PUT_LINE('That Was A ' || ORA_SYSEVENT);
END;

-- drop a table
DROP TABLE abc

DROP TRIGGER all_ddl

CREATE OR REPLACE TRIGGER get_ddl
BEFORE DDL
ON SCHEMA
DECLARE
  v_ddl_linecount NUMBER;
  v_sql           ORA_NAME_LIST_T;
BEGIN
  v_ddl_linecount := ora_sql_txt(v_sql);
  FOR counter IN 1..v_ddl_linecount LOOP
    DBMS_OUTPUT.PUT_LINE(counter || ' ' || v_sql(counter));
  END LOOP;
END;

CREATE TABLE bob
( col1 NUMBER );

ALTER TABLE bob ADD ( col2 NUMBER );

-- triggers catches dynamic DDL as well
CREATE OR REPLACE PROCEDURE no_bob AS
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE bob';
END;

BEGIN
  no_bob;
END;

DROP TRIGGER get_ddl

CREATE TABLE bob
( col1 NUMBER );

CREATE OR REPLACE TRIGGER get_grants
BEFORE DDL
ON SCHEMA
DECLARE
  v_priv_count NUMBER;
  v_privs      ORA_NAME_LIST_T;
BEGIN
  v_priv_count := ora_privilege_list(v_privs);
  DBMS_OUTPUT.PUT_LINE('Actual privileges granted:');
  FOR counter IN 1..v_priv_count LOOP
    DBMS_OUTPUT.PUT_LINE(v_privs(counter));
  END LOOP;
END;

GRANT ALL ON BOB TO PUBLIC;

DROP TRIGGER get_grants;

-- create a DDL trigger that will fail
CREATE TRIGGER raise_exception
BEFORE DDL
ON SCHEMA
DECLARE
  v_number NUMBER;
BEGIN
  v_number := 'ABC';
END;

CREATE TABLE abc
(col1 NUMBER )

-- create trigger that will raise no data found
CREATE OR REPLACE TRIGGER raise_exception
BEFORE DDL
ON SCHEMA
DECLARE
  v_number NUMBER;
BEGIN
  SELECT animal_id
    INTO v_number
    FROM animal
   WHERE 1 = 2;
END;

CREATE TABLE abc
(col1 NUMBER )
