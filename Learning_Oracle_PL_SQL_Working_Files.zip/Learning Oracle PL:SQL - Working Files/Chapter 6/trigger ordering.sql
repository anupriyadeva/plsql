SET SQLFORMAT ansiconsole

BEGIN
  FOR x IN ( SELECT trigger_name
               FROM user_triggers ) LOOP
    EXECUTE IMMEDIATE 'DROP TRIGGER ' || x.trigger_name;
  END LOOP;
END;

DELETE animal WHERE animal_id > 2;
DELETE animal WHERE animal_id IS NULL;

SELECT *
  FROM animal
ORDER BY animal_id

-- create "first" trigger
CREATE OR REPLACE TRIGGER animal_one
BEFORE INSERT ON animal
FOR EACH ROW
BEGIN
  :NEW.animal_id := 33;
  DBMS_OUTPUT.PUT_LINE('One');
END;

-- create "second" trigger
CREATE OR REPLACE TRIGGER animal_two
BEFORE INSERT ON animal
FOR EACH ROW
BEGIN
  IF :NEW.animal_id = 33 THEN
    :NEW.animal_id := 66;
  END IF;
  DBMS_OUTPUT.PUT_LINE('Two');
END;

-- create "third" trigger
CREATE OR REPLACE TRIGGER animal_three
BEFORE INSERT ON animal
FOR EACH ROW
BEGIN
  IF :NEW.animal_id = 66 THEN
    :NEW.animal_id := 99;
  END IF;
  DBMS_OUTPUT.PUT_LINE('Three');
END;

INSERT INTO animal
VALUES(33,'Leopard');

SELECT *
  FROM animal

ROLLBACK
  
-- create "second" trigger with follows clause
CREATE OR REPLACE TRIGGER animal_two
BEFORE INSERT ON animal
FOR EACH ROW
FOLLOWS animal_one
BEGIN
  IF :NEW.animal_id = 33 THEN
    :NEW.animal_id := 66;
  END IF;
  DBMS_OUTPUT.PUT_LINE('Two');
END;

-- create "third" trigger with follows clause
CREATE OR REPLACE TRIGGER animal_three
BEFORE INSERT ON animal
FOR EACH ROW
FOLLOWS animal_two
BEGIN
  IF :NEW.animal_id = 66 THEN
    :NEW.animal_id := 99;
  END IF;
  DBMS_OUTPUT.PUT_LINE('Three');
END;

INSERT INTO animal
VALUES(33,'Leopard');

SELECT *
  FROM animal
