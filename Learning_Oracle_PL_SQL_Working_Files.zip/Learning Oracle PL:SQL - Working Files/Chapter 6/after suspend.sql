SELECT *
  FROM demo

-- set users maximum space to 1K
ALTER USER drh QUOTA 1K ON USERS

-- attempt to create records that will exceed users quota
BEGIN
  FOR counter IN 1..10000 LOOP
    INSERT INTO demo
    VALUES(RPAD(counter,30,counter));
  END LOOP;
END;

-- set session to enter a resumable state for 5 seconds
-- if it encounters a space error such as max space allocated
DISCONNECT
CONNECT drh/drhdrh
ALTER SESSION ENABLE RESUMABLE TIMEOUT 5

CREATE OR REPLACE TRIGGER after_suspend
AFTER SUSPEND
ON SCHEMA
BEGIN
  RAISE_APPLICATION_ERROR(-20000,'Forced Suspend To Fail');
END;

CREATE TABLE suspend_log
( log_timestamp TIMESTAMP,
  error_type    VARCHAR2(30),
  we_can_help   VARCHAR2(3),
  we_did_help   VARCHAR2(3))
TABLESPACE USERS2;

CREATE OR REPLACE TRIGGER after_suspend
AFTER SUSPEND
ON SCHEMA
DECLARE
  v_error_type        VARCHAR2(30);
  v_object_type       VARCHAR2(30); 
  v_object_owner      VARCHAR2(30); 
  v_table_space_name  VARCHAR2(30); 
  v_object_name       VARCHAR2(30); 
  v_sub_object_name   VARCHAR2(30);
BEGIN
  IF ORA_SPACE_ERROR_INFO( v_error_type, 
                           v_object_type, 
                           v_object_owner, 
                           v_table_space_name, 
                           v_object_name, 
                           v_sub_object_name) THEN

    INSERT INTO suspend_log
    VALUES(SYSTIMESTAMP,
          v_error_type,
          'YES',
          'NO');
  ELSE
    INSERT INTO suspend_log
    VALUES(SYSTIMESTAMP,
          'UNKNOWN',
          'NO',
          'NO');
    DBMS_RESUMABLE.SET_TIMEOUT(0);
  END IF;
END;

SELECT *
  FROM suspend_log
  
CREATE OR REPLACE TRIGGER after_suspend
AFTER SUSPEND
ON SCHEMA
DECLARE
  v_error_type        VARCHAR2(30);
  v_object_type       VARCHAR2(30); 
  v_object_owner      VARCHAR2(30); 
  v_table_space_name  VARCHAR2(30); 
  v_object_name       VARCHAR2(30); 
  v_sub_object_name   VARCHAR2(30);
BEGIN
  IF ORA_SPACE_ERROR_INFO( v_error_type, 
                           v_object_type, 
                           v_object_owner, 
                           v_table_space_name, 
                           v_object_name, 
                           v_sub_object_name) THEN

    IF v_error_type = 'SPACE QUOTA EXCEEDED' THEN
    
      EXECUTE IMMEDIATE 'ALTER USER ' || ora_login_user ||
                        ' QUOTA UNLIMITED ON ' || v_object_name;
    END IF;

    INSERT INTO suspend_log
    VALUES(SYSTIMESTAMP,
          v_error_type,
          'YES',
          'YES');
  ELSE
    INSERT INTO suspend_log
    VALUES(SYSTIMESTAMP,
          'UNKNOWN',
          'NO',
          'NO');
    DBMS_RESUMABLE.SET_TIMEOUT(0);
  END IF;
END;

CREATE OR REPLACE TRIGGER after_suspend
AFTER SUSPEND
ON SCHEMA
DECLARE
  v_error_type        VARCHAR2(30);
  v_object_type       VARCHAR2(30); 
  v_object_owner      VARCHAR2(30); 
  v_table_space_name  VARCHAR2(30); 
  v_object_name       VARCHAR2(30); 
  v_sub_object_name   VARCHAR2(30);
BEGIN
  IF ORA_SPACE_ERROR_INFO( v_error_type, 
                           v_object_type, 
                           v_object_owner, 
                           v_table_space_name, 
                           v_object_name, 
                           v_sub_object_name) THEN

    -- submit job to avoid oracle error
    IF v_error_type = 'SPACE QUOTA EXCEEDED' THEN
      --
      -- submits job to avoid ORA-30511: invalid DDL operation in system triggers
      --
      DBMS_SCHEDULER.CREATE_JOB ( job_name             => 'FIX_SUSPENDED_SESSION',
                                  job_type             => 'PLSQL_BLOCK',
                                  job_action           => 'BEGIN ' ||
                                                             'EXECUTE IMMEDIATE '   || '''' || 'ALTER USER ' || ora_login_user ||
                                                             ' QUOTA UNLIMITED ON ' || v_object_name  || '''' || ';' ||
                                                          'END;',
                                  start_date           => SYSTIMESTAMP,
                                  enabled              =>  TRUE);
    END IF;

    INSERT INTO suspend_log
    VALUES(SYSTIMESTAMP,
          v_error_type,
          'YES',
          'YES');
  ELSE
    INSERT INTO suspend_log
    VALUES(SYSTIMESTAMP,
          'UNKNOWN',
          'NO',
          'NO');
    DBMS_RESUMABLE.SET_TIMEOUT(0);
  END IF;
END;
