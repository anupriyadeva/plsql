SET SQLFORMAT ansiconsole

BEGIN
  FOR x IN ( SELECT trigger_name
               FROM user_triggers ) LOOP
    EXECUTE IMMEDIATE 'DROP TRIGGER ' || x.trigger_name;
  END LOOP;
END;

DROP SEQUENCE animal_seq; 
CREATE SEQUENCE animal_seq START WITH 3;
DELETE animal WHERE animal_id > 2;
DELETE animal WHERE animal_id IS NULL;

SELECT *
  FROM animal
ORDER BY animal_id

-- row level trigger to manufacture animal ID
-- from sequence before the record is inserted
CREATE OR REPLACE TRIGGER before_animal_row
BEFORE INSERT ON ANIMAL
FOR EACH ROW
BEGIN
  :NEW.animal_id := animal_seq.nextval;
  DBMS_OUTPUT.PUT_LINE('Before Row ' || :NEW.animal_id);
END;

INSERT INTO animal(animal_name)
VALUES('Tiger');

-- row level trigger after insert
CREATE OR REPLACE TRIGGER after_animal_row
AFTER INSERT ON ANIMAL
FOR EACH ROW
BEGIN
  :NEW.animal_id := animal_seq.nextval;
  DBMS_OUTPUT.PUT_LINE('After Row ' || :NEW.animal_id);
END;

-- create statement/table level trigger before insert
CREATE OR REPLACE TRIGGER before_animal_table
BEFORE INSERT ON ANIMAL
BEGIN
  :NEW.animal_id := animal_seq.nextval;
  DBMS_OUTPUT.PUT_LINE('Before Statement');
END;

-- create statement/table level trigger after insert
CREATE OR REPLACE TRIGGER after_animal_table
AFTER INSERT ON ANIMAL
BEGIN
  :NEW.animal_id := animal_seq.nextval;
  DBMS_OUTPUT.PUT_LINE('After Statement');
END;

-- bulk insert 3 rows
DECLARE
  TYPE v_vc230_t IS TABLE OF VARCHAR2(30);
  v_animal v_vc230_t := v_vc230_t() ;
BEGIN
  v_animal.EXTEND(3);
  v_animal(1) := 'Elephant';
  v_animal(2) := 'Hippo';
  v_animal(3) := 'Snake';
  FORALL counter IN 1..3
    INSERT INTO animal(animal_name)
    VALUES(v_animal(counter));
END;

ALTER TRIGGER BEFORE_ANIMAL_ROW DISABLE

INSERT INTO animal(animal_name)
VALUES('Albatross');

-- check trigger definitions in the database
SELECT trigger_name,
       trigger_type,
       triggering_event
  FROM user_triggers

-- frop triggers
DROP TRIGGER before_animal_table;
DROP TRIGGER before_animal_row;
DROP TRIGGER after_animal_row;
DROP TRIGGER after_animal_table;

-- one trigger for multiple DML types
CREATE OR REPLACE TRIGGER animal_dml 
BEFORE INSERT OR UPDATE OR DELETE ON animal
BEGIN
  IF INSERTING THEN
    DBMS_OUTPUT.PUT_LINE('Inserting');
  ELSIF DELETING THEN
       DBMS_OUTPUT.PUT_LINE('Deleting');
  ELSIF UPDATING THEN
       DBMS_OUTPUT.PUT_LINE('Updating');
  ELSE
       DBMS_OUTPUT.PUT_LINE('What Are You Doing?');
  END IF;
END;

-- perform DML
INSERT INTO animal
VALUES(99,'Crocodile');
UPDATE animal
SET animal_name = 'Not Crocodile'
WHERE animal_id = 99;
DELETE animal
WHERE animal_id = 99;

DROP TRIGGER animal_dml

-- trigger to display records being updated or deleted
CREATE OR REPLACE TRIGGER animal_dml 
BEFORE UPDATE OR DELETE ON animal
FOR EACH ROW
BEGIN
  IF DELETING THEN
    DBMS_OUTPUT.PUT_LINE('Deleting '    ||
                         :OLD.animal_id || ' ' ||
                         :OLD.animal_name);
  ELSIF UPDATING THEN
       DBMS_OUTPUT.PUT_LINE('Updating '      ||
                            :OLD.animal_id   || ' '    ||
                            :OLD.animal_name || ' To ' ||
                            :NEW.animal_id   || ' '    ||
                            :NEW.animal_name);
  END IF;
END;

UPDATE animal
SET animal_name = 'ANIMAL ' || animal_id
WHERE MOD(animal_id,2) = 0

DELETE animal
WHERE MOD(animal_id,2) <> 0

DROP TRIGGER animal_dml

-- trigger to prevent deletes or updates
CREATE OR REPLACE TRIGGER animal_dml 
BEFORE UPDATE OR DELETE ON animal
BEGIN
  IF DELETING THEN
    RAISE_APPLICATION_ERROR(-20000,'No Deletes Allowed');
  ELSIF UPDATING THEN
    RAISE_APPLICATION_ERROR(-20001,'No Updates Allowed');
  END IF;
END;

DELETE animal;

UPDATE animal
SET animal_name = 'BOB';

DROP TRIGGER animal_dml

-- trigger firing for specific column and having specific
-- value. Also renames OLD and NEW structures
CREATE OR REPLACE TRIGGER before_update
BEFORE UPDATE OF animal_id ON animal
REFERENCING OLD AS old_rec NEW AS new_rec
FOR EACH ROW
WHEN ( old_rec.animal_id > 0 )
BEGIN
  RAISE_APPLICATION_ERROR(-20000,'Cant Update ID ' || :old_rec.animal_id);
END;

UPDATE animal
SET animal_name = 'BOB';

ROLLBACK;

UPDATE animal
SET animal_id = animal_id
WHERE animal_id > 1;
