SET SQLFORMAT ANSICONSOLE
SET LINES 132
SET PAGES 100
COLUMN name FORMAT a10
COLUMN type FORMAT a15
COLUMN referenced_name FORMAT a10
COLUMN referenced_type FORMAT a15

CREATE TABLE a_table
( col1 NUMBER(10) );
 
CREATE PROCEDURE a_proc AS
BEGIN
  UPDATE a_table
  SET col1 = col1;
END;
 
SELECT name,
       type,
       referenced_name,
       referenced_type
  FROM user_dependencies
 WHERE referenced_owner = USER

SELECT object_name,
       object_type,
       status
  FROM user_objects;
 
BEGIN
  a_proc;
END;

ALTER TABLE a_table
MODIFY ( col1 NUMBER(20) );

DROP PROCEDURE a_proc

CREATE OR REPLACE PACKAGE a_pkg AS
  PROCEDURE pkg_proc;
END;

CREATE OR REPLACE PACKAGE BODY a_pkg AS
  v_variable NUMBER := 11;
  PROCEDURE pkg_proc IS
  BEGIN
    UPDATE a_table
    SET col1 = col1;
    NULL;
  END;
END;

SELECT name,
       type,
       referenced_name,
       referenced_type
  FROM user_dependencies
 WHERE referenced_owner = USER

SELECT object_name,
       object_type,
       status
  FROM user_objects;

BEGIN
  a_pkg.pkg_proc;
END;

ALTER TABLE a_table
MODIFY ( col1 NUMBER(20) );

ALTER SYSTEM SET plsql_native_library_dir='C:\TEMP';  -- obsolete?
ALTER PROCEDURE a_proc COMPILE PLSQL_CODE_TYPE=NATIVE;

