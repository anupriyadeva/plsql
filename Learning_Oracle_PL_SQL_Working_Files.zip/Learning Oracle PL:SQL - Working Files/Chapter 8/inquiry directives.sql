SET SQLFORMAT ANSICONSOLE
SET LINESIZE 132
SET PAGESIZE 300

COLUMN name FORMAT a10
COLUMN plsql_ccflags FORMAT a20
COLUMN text FORMAT a132

-- create a procedure with conditional compilation code
-- that is based on a cc flag
CREATE OR REPLACE PROCEDURE a_proc ( p_id NUMBER ) IS
  v_local NUMBER;
BEGIN
  v_local := p_id;
  $IF $$DOUBLE_EVERYTHING $THEN
    v_local := v_local * 2;
  $END
  DBMS_OUTPUT.PUT_LINE(v_local);
END;

-- check the cc flag settings
SELECT name,
       plsql_ccflags
  FROM user_plsql_object_settings

-- execute the code
BEGIN
  a_proc(99);
END;

ALTER PROCEDURE a_proc COMPILE plsql_ccflags='DOUBLE_EVERYTHING:TRUE'

ALTER SESSION SET plsql_ccflags='DOUBLE_EVERYTHING:TRUE'

ALTER PROCEDURE a_proc COMPILE REUSE SETTINGS

-- procedure with debug values
CREATE OR REPLACE PROCEDURE a_proc ( p_id NUMBER ) IS
  v_var NUMBER(1) := 1;
BEGIN
  $IF $$DEBUG $THEN
    DBMS_OUTPUT.PUT_LINE('Passed in ' || p_id);
  $END
  v_var := v_var * 10;
EXCEPTION
  WHEN OTHERS THEN
  $IF $$DEBUG $THEN
    DBMS_OUTPUT.PUT_LINE('v_var was ' || v_var);
  $END
  RAISE;  
END;

BEGIN
  a_proc(8);
END;

ALTER PROCEDURE a_proc COMPILE plsql_ccflags='DEBUG:TRUE'

CREATE OR REPLACE PROCEDURE a_proc ( p_id NUMBER ) IS
  v_var NUMBER(1) := 1;
BEGIN
  $IF $$DEBUG $THEN
    DBMS_OUTPUT.PUT_LINE($$PLSQL_LINE || ' of ' || $$PLSQL_UNIT);
  $END
  v_var := v_var * 10;
  $IF $$DEBUG $THEN
    DBMS_OUTPUT.PUT_LINE($$PLSQL_LINE || ' of ' || $$PLSQL_UNIT);
  $END
EXCEPTION
  WHEN OTHERS THEN
  $IF $$DEBUG $THEN
    DBMS_OUTPUT.PUT_LINE($$PLSQL_LINE || ' of ' || $$PLSQL_UNIT);
  $END
  RAISE;  
END;

ALTER PROCEDURE a_proc COMPILE plsql_ccflags='DEBUG:FALSE'

BEGIN
  DBMS_PREPROCESSOR.PRINT_POST_PROCESSED_SOURCE (
                                       'PROCEDURE',
                                       USER,
                                      'A_PROC');
END;
  