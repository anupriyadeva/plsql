SET SQLFORMAT ANSICONSOLE
SET LINES 132
SET PAGES 100

COLUMN name FORMAT a15
COLUMN type FORMAT a10
COLUMN text FORMAT a200

-- set optimize level
ALTER SESSION SET PLSQL_OPTIMIZE_LEVEL = 3;
 
-- enable compiler messages to explain optimizations
ALTER SESSION SET PLSQL_WARNINGS="ENABLE:INFORMATIONAL";

-- create procedure with uncalled code
CREATE OR REPLACE PROCEDURE optimize_me AS
  FUNCTION will_never_get_called
           RETURN NUMBER AS
  BEGIN
    RETURN(11);
  END;
BEGIN
  DBMS_OUTPUT.PUT_LINE('Hello');
END;

-- get warning message from user_errors view
SELECT name,
       type,
       text
  FROM user_errors

-- set optimize level
ALTER SESSION SET PLSQL_OPTIMIZE_LEVEL = 3;

-- create procedure with opportunity for inlining
CREATE OR REPLACE PROCEDURE optimize_me AS
  v_number NUMBER;
  FUNCTION no_return RETURN NUMBER IS
  BEGIN
    RETURN(11);
  END;
BEGIN
  v_number := no_return;
END;

CREATE OR REPLACE PROCEDURE optimize_me AS
  v_dummy VARCHAR2(1);
BEGIN
  SELECT NULL
    INTO v_dummy
    FROM DUAL;
END;

PLW-07206: analysis suggests that the assignment to 'string' may be unnecessary
