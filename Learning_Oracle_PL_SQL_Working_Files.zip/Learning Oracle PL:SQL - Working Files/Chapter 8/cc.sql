-- version specific code that compile against all versions
CREATE OR REPLACE PROCEDURE version_sensitive_code AS
BEGIN
  IF DBMS_DB_VERSION.VER_LE_11 THEN
    DBMS_OUTPUT.PUT_LINE('Version 11 code here');
  ELSIF DBMS_DB_VERSION.VER_LE_12 THEN
      DBMS_OUTPUT.PUT_LINE('Version 12 code here');
  ELSE
    DBMS_OUTPUT.PUT_LINE('Code only works on 11 and 12');
  END IF;
END;

BEGIN
  version_sensitive_code;
END;

-- version specific code that does not compile against all versions
CREATE OR REPLACE PROCEDURE version_sensitive_code AS
BEGIN
  $IF DBMS_DB_VERSION.VER_LE_11
  $THEN
    DBMS_OUTPUT.PUT_LINE('Version 11 code here');
  $ELSIF DBMS_DB_VERSION.VER_LE_12
  $THEN
      DBMS_OUTPUT.PUT_LINE('Version 12 code here');
  $ELSE
    DBMS_OUTPUT.PUT_LINE('Code only works on 11 and 12');
  $END
END;

-- package to hold debug settings
CREATE OR REPLACE PACKAGE debug_flags AS
  v_debug_level NUMBER := 2;
END;

-- procedure that refeernces debug settings
CREATE OR REPLACE PROCEDURE debuggable ( p_id NUMBER ) AS
  v_local NUMBER := 1;
BEGIN
  IF debug_flags.v_debug_level > 0 THEN
    DBMS_OUTPUT.PUT_LINE('p_id ' || p_id);
  END IF;
  FOR counter IN 1..p_id LOOP
    v_local := v_local * p_id;
    IF debug_flags.v_debug_level > 1 THEN
      DBMS_OUTPUT.PUT_LINE(counter || ' v_local ' || v_local);
    END IF; 
  END LOOP;
END;

-- code will get recompiled when package settings change
BEGIN
  debuggable(11);
END;

CREATE OR REPLACE PROCEDURE debuggable ( p_id NUMBER ) AS
  v_local NUMBER := 1;
BEGIN
  $IF debug_flags.v_debug_level > 0 $THEN
--  $IF debug_flags.v_show_params $THEN
    DBMS_OUTPUT.PUT_LINE('p_id ' || p_id);
  $END
  FOR counter IN 1..p_id LOOP
    v_local := v_local * p_id;
    $IF debug_flags.v_debug_level > 1 $THEN
--     $IF debug_flags.v_show_loop $THEN
      DBMS_OUTPUT.PUT_LINE(counter || ' v_local ' || v_local);
    $END 
  END LOOP;
END;

-- debug package with boolean constants
CREATE OR REPLACE PACKAGE debug_flags AS
  v_show_params CONSTANT BOOLEAN := TRUE;
  v_show_loop   CONSTANT BOOLEAN := TRUE;
END;

-- add detail flag
CREATE OR REPLACE PACKAGE debug_flags AS
  v_show_params CONSTANT BOOLEAN := TRUE;
  v_show_loop   CONSTANT BOOLEAN := TRUE;
  v_show_detail CONSTANT BOOLEAN := TRUE;
END;

CREATE OR REPLACE PROCEDURE debuggable ( p_id NUMBER ) AS
  v_local NUMBER := 1;
BEGIN
  $IF debug_flags.v_show_detail $THEN
     DBMS_OUTPUT.PUT_LINE($$PLSQL_CODE_TYPE);
     $IF DBMS_DB_VERSION.VER_LE_9 $THEN
       NULL;
     $ELSE
       DBMS_OUTPUT.PUT_LINE($$PLSQL_OPTIMIZE_LEVEL);
     $END
  $END
  $IF debug_flags.v_show_params $THEN
    DBMS_OUTPUT.PUT_LINE('p_id ' || p_id);
  $END
  FOR counter IN 1..p_id LOOP
    v_local := v_local * p_id;
    $IF debug_flags.v_show_loop $THEN
      DBMS_OUTPUT.PUT_LINE(counter || ' v_local ' || v_local);
    $END 
  END LOOP;
END;

-- $ERROR directive to ensure code does not compile and get used!
CREATE OR REPLACE PROCEDURE for_version_11_only AS
BEGIN
  $IF DBMS_DB_VERSION.VERSION <> 11 THEN
  $ERROR
  'DONT RUN THIS ONL ANYTHING EXCEPT 11'
  $END
  $END
END;
