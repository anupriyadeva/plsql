-- create a package or replace an existing one
CREATE OR REPLACE PACKAGE a_pkg AS

  v_public_variable VARCHAR2(100) := 'PUBLIC';

END;

-- create a package body or replace an existing one
CREATE OR REPLACE PACKAGE BODY a_pkg AS

  v_private_variable VARCHAR2(100) := 'PRIVATE';

END;

-- output and set a public variable
BEGIN
  DBMS_OUTPUT.PUT_LINE(a_pkg.v_public_variable);
  a_pkg.v_public_variable := a_pkg.v_public_variable || '1';
  DBMS_OUTPUT.PUT_LINE(a_pkg.v_public_variable);  
END;

-- try to output a package body variable directly
BEGIN
  DBMS_OUTPUT.PUT_LINE(a_pkg.v_private_variable);
END;

CREATE OR REPLACE PACKAGE BODY a_pkg AS

  v_private_variable VARCHAR2(100) := 'PRIVATE';

  -- define a function to return the private variable
  FUNCTION get_private RETURN VARCHAR2 IS
  BEGIN
    RETURN(v_private_variable);
  END;

  -- define a procedure to set the local variable
  PROCEDURE set_private ( p_value VARCHAR2 ) IS
  BEGIN
    v_private_variable := p_value;
  END;
  
END;

-- create the package header
CREATE OR REPLACE PACKAGE a_pkg AS

  v_public_variable VARCHAR2(100) := 'PUBLIC';

--  FUNCTION get_private RETURN VARCHAR2;

--  PROCEDURE set_private ( p_value VARCHAR2 );
  
END;

-- attempt to access package body function which will
-- not work until declared in header
BEGIN
  DBMS_OUTPUT.PUT_LINE(a_pkg.get_private);
END;

-- attempt to access package body functiona which will
-- not work until declared in header
BEGIN
  a_pkg.set_private('ABC');
  DBMS_OUTPUT.PUT_LINE(a_pkg.get_private);
END;
