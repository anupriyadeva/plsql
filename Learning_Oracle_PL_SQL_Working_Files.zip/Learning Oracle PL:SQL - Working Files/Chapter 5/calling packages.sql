-- package with procedure with in out parameters
CREATE OR REPLACE PACKAGE in_and_out AS

  PROCEDURE in_and_out ( p_in  IN            NUMBER,
                         p_out OUT           NUMBER,
                         p_in_and_out IN OUT NUMBER );
                         
END;

CREATE OR REPLACE PACKAGE BODY in_and_out AS

  PROCEDURE in_and_out ( p_in  IN            NUMBER,
                         p_out OUT           NUMBER,
                         p_in_and_out IN OUT NUMBER ) IS
  BEGIN
    p_out := p_in * 10;
    p_in_and_out := p_in_and_out * p_out;
  END;
                         
END;

-- call procedure in package with in out paremeters
DECLARE
  v_in         NUMBER := 1;
  v_out        NUMBER;
  v_in_and_out NUMBER := 3;
BEGIN
  in_and_out.in_and_out(v_in,v_out,v_in_and_out);
  DBMS_OUTPUT.PUT_LINE(v_in || ' ' || v_out || ' ' || v_in_and_out);
END;

-- package with a function
CREATE OR REPLACE PACKAGE functional AS

  FUNCTION func_one ( p_id NUMBER ) RETURN NUMBER;
  
END;

-- package body with a function
CREATE OR REPLACE PACKAGE BODY functional AS

  FUNCTION func_one ( p_id NUMBER ) RETURN NUMBER IS
  BEGIN
    RETURN(p_id * 10);
  END;
  
END;

-- calling function in a package
BEGIN
  DBMS_OUTPUT.PUT_LINE(functional.func_one(9));
END;

-- package with public variable
CREATE OR REPLACE PACKAGE public_var AS

  v_public_var NUMBER := 1;
  
END;

BEGIN
  FOR counter IN 1..5 LOOP
    public_var.v_public_var := public_var.v_public_var + counter;
    DBMS_OUTPUT.PUT_LINE(public_var.v_public_var);
  END LOOP;
END;

-- package with a cursor
CREATE OR REPLACE PACKAGE cursors AS

  CURSOR curs_get_animal ( p_id NUMBER ) IS
  SELECT *
    FROM animal
   WHERE animal_id = p_id;

END;

-- procedure to use package cursor
DECLARE
  v_local_animal cursors.curs_get_animal%ROWTYPE;
BEGIN
  OPEN cursors.curs_get_animal(2);
  FETCH cursors.curs_get_animal INTO v_local_animal;
  DBMS_OUTPUT.PUT_LINE(v_local_animal.animal_name);
  CLOSE cursors.curs_get_animal;
END;
