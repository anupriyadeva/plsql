-- create a package or replace an existing one
CREATE OR REPLACE PACKAGE a_pkg AS

  PROCEDURE a_proc ( p_id NUMBER );
  FUNCTION a_func ( p_id NUMBER ) RETURN NUMBER;
 
  v_variable NUMBER := 11;

END;

-- create a package or replace an existing one
-- this one is missing a function declared in header
CREATE OR REPLACE PACKAGE BODY a_pkg AS

  PROCEDURE a_proc ( p_id NUMBER ) IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE(p_id);
  END;
  
END;

-- create package body to match header and
-- include a function that is private to the package body
CREATE OR REPLACE PACKAGE BODY a_pkg AS

  v_another_variable NUMBER := 11;

  PROCEDURE a_proc ( p_id NUMBER ) IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE(p_id);
  END;
  
  FUNCTION a_func ( p_id NUMBER ) RETURN NUMBER IS
  BEGIN
    RETURN(p_id);
  END;

  FUNCTION only_in_body RETURN NUMBER IS
  BEGIN
    NULL;
  END;
 
END;

-- check for object in DB
SELECT object_name,
       object_type,
       status
  FROM user_objects
 WHERE object_name = 'A_PKG'

-- try to execute procedure in package
BEGIN
  a_pkg.a_proc(99);
END;

-- create procedure to call package
CREATE OR REPLACE PROCEDURE a_proc AS
BEGIN
  a_pkg.a_proc(66);
END;

-- execute the procedure
BEGIN
  a_proc;
END;

-- query dependency from the database
SELECT name,
       type,
       referenced_name,
       referenced_type
  FROM user_dependencies
 WHERE name IN ('A_PKG','A_PROC')
   AND referenced_name IN ('A_PKG','A_PROC')
