-- create a package or replace an existing one
CREATE OR REPLACE PACKAGE a_pkg AS

  v_variable NUMBER := 11;

  PROCEDURE a_proc ( p_id NUMBER );
  FUNCTION a_func ( p_id NUMBER ) RETURN NUMBER;
 
END;

-- check for object in DB
SELECT object_name,
       object_type,
       status
  FROM user_objects
 WHERE object_name = 'A_PKG'

-- try to execute procedure in package
BEGIN
  a_pkg.a_proc(1);
END;

-- output a package variable
BEGIN
  DBMS_OUTPUT.PUT_LINE(a_pkg.v_variable);
END;

-- modify and output a package variable
BEGIN
  DBMS_OUTPUT.PUT_LINE(a_pkg.v_variable);
  a_pkg.v_variable := a_pkg.v_variable * 2;
  DBMS_OUTPUT.PUT_LINE(a_pkg.v_variable);
END;

-- compile (and reset) a packages
ALTER PACKAGE a_pkg COMPILE

-- create a procedure that calls the package
CREATE OR REPLACE PROCEDURE a_proc AS
BEGIN
  a_pkg.a_proc(2);
END;

-- excecute procedure that calls package
BEGIN
  a_proc;
END;

-- query dependency from the database
SELECT name,
       type,
       referenced_name,
       referenced_type
  FROM user_dependencies
 WHERE name IN ('A_PKG','A_PROC')
   AND referenced_name IN ('A_PKG','A_PROC')
   
-- check status of procedure that calls
-- package
SELECT object_name,
       object_type,
       status
  FROM user_objects
 WHERE object_name = 'A_PROC'