DECLARE
  -- basic scalar variables
  v_vc2 VARCHAR2(1000) := 'ABC';
  v_n  NUMBER          := 1.23;
  v_i  INTEGER         := 1.3;
  v_p  PLS_INTEGER     := 1.4;
BEGIN
  DBMS_OUTPUT.PUT_LINE(v_vc2);
  DBMS_OUTPUT.PUT_LINE(v_n);
  DBMS_OUTPUT.PUT_LINE(v_i);
  DBMS_OUTPUT.PUT_LINE(v_p);
END;

DECLARE
  -- stuff too many characters in
  v_vc2_1 VARCHAR2(1);
BEGIN
  v_vc2_1 := 'A';
  v_vc2_1 := v_vc2_1 || 'B';
END;

DECLARE
  -- cannot put characters into numeric variables
  v_n_t NUMBER;
BEGIN
  v_n_t := 'ABC';
END;

CREATE TABLE animal
( animal_id number, animal_name varchar2(30));

INSERT INTO animal
VALUES(1,'Zebra');

DECLARE
  v_animal_name VARCHAR2(2);
BEGIN
  SELECT animal_name
    INTO v_animal_name
    FROM animal;
END;

DECLARE
  -- acnhored variable for query
  v_animal_name animal.animal_name%TYPE;
BEGIN
  SELECT animal_name
    INTO v_animal_name
    FROM animal;
END;

