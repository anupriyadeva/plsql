BEGIN
  -- simplest block of SQL
  NULL;
END;

DECLARE
  v_variable NUMBER;
BEGIN
  -- simple code block with 1 variable
  v_variable := 1;
  DBMS_OUTPUT.PUT_LINE('v_variable = ' || v_variable);
END;

BEGIN
  -- embedded blocks
  DBMS_OUTPUT.PUT_LINE('First Block');
  BEGIN
    DBMS_OUTPUT.PUT_LINE('Second Block');
  END;
END;

DECLARE
  -- embedded block and variables
  v_outer_variable NUMBER := 1;
BEGIN
  DECLARE
    v_inner_variable NUMBER := 2;
  BEGIN
    DBMS_OUTPUT.PUT_LINE(v_outer_variable || ' ' ||
                         v_inner_variable);
  END;
END;

DECLARE
  -- embedded block and duplicate variable names
  v_outer_variable NUMBER := 1;
BEGIN
  DECLARE
    v_outer_variable NUMBER := 2;
  BEGIN
    DBMS_OUTPUT.PUT_LINE(v_outer_variable);
  END;
  DBMS_OUTPUT.PUT_LINE(v_outer_variable);
END;

DECLARE
  -- embedded block and variables
  v_outer_variable NUMBER := 1;
BEGIN
  DECLARE
    v_inner_variable NUMBER := 2;
  BEGIN
    DBMS_OUTPUT.PUT_LINE(v_outer_variable || ' ' ||
                         v_inner_variable);
  END;
  -- fails because v_inner_variable is out of scope
  DBMS_OUTPUT.PUT_LINE(v_outer_variable || ' ' ||
                       v_inner_variable);
END;

CREATE OR REPLACE PROCEDURE abc AS
  -- block structure within a procedure
BEGIN
  DBMS_OUTPUT.PUT_LINE('Hello');
END;
/

BEGIN
  -- block structure when calling a procedure
  abc;
END;

DROP PROCEDURE def;

CREATE PROCEDURE def AS
  -- end labels
  PROCEDURE ghi IS
  BEGIN
    NULL;
  END ghi;
BEGIN
  NULL;
END def;

BEGIN
  -- label defined in code
  <<label_one>>
  BEGIN
    NULL;
  END label_one;
END;
