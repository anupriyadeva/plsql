DECLARE

  -- table type and variable
  TYPE v_varray_t IS VARRAY(3) OF VARCHAR2(30);
  v_varray v_varray_t := v_varray_t();
  
BEGIN

  -- add 3 entries
  v_varray.EXTEND(3);    
  v_varray(1) := 'A';
  v_varray(2) := 'B';
  v_varray(3) := 'C';
  
  DBMS_OUTPUT.PUT_LINE('...when 3 entries added...');
  DBMS_OUTPUT.PUT_LINE('Table Count ' || v_varray.COUNT);
  DBMS_OUTPUT.PUT_LINE('Table First ' || v_varray.FIRST);
  DBMS_OUTPUT.PUT_LINE('Table Last  ' || v_varray.LAST);

  v_varray.DELETE;

  DBMS_OUTPUT.PUT_LINE('...simple for loop..');
  FOR counter IN 1..v_varray.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE(counter || ' ' || v_varray(counter));
  END LOOP;

  DBMS_OUTPUT.PUT_LINE('...first and next..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_varray.FIRST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_varray(v_counter));
      v_counter := v_varray.NEXT(v_counter);
    END LOOP;
  END;

  DBMS_OUTPUT.PUT_LINE('...last and prior..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_varray.LAST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_varray(v_counter));
      v_counter := v_varray.PRIOR(v_counter);
    END LOOP;
  END;
 
END;
