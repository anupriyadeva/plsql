DECLARE

  -- index-by type and variable
  TYPE v_index_by_t IS TABLE OF VARCHAR2(30)
    INDEX BY BINARY_INTEGER;
  v_ib v_index_by_t;
  
  -- table type and variable
  TYPE v_table_t IS TABLE OF VARCHAR2(20);
  v_table v_table_t := v_table_t();
  
  -- varray type and variable
  TYPE v_varray_t IS VARRAY(4) OF VARCHAR2(20);
  v_varray v_varray_t := v_varray_t();
  
BEGIN

  DBMS_OUTPUT.PUT_LINE('...when Empty...');
  DBMS_OUTPUT.PUT_LINE('Index By Count ' || v_ib.COUNT);
  DBMS_OUTPUT.PUT_LINE('Table Count    ' || v_table.COUNT);
  DBMS_OUTPUT.PUT_LINE('VARRAY Count   ' || v_varray.COUNT);

  DBMS_OUTPUT.PUT_LINE('Index By First ' || v_ib.FIRST);
  DBMS_OUTPUT.PUT_LINE('Table First    ' || v_table.FIRST);
  DBMS_OUTPUT.PUT_LINE('VARRAY First   ' || v_varray.FIRST);

  DBMS_OUTPUT.PUT_LINE('Index By Last  ' || v_ib.LAST);
  DBMS_OUTPUT.PUT_LINE('Table Last     ' || v_table.LAST);
  DBMS_OUTPUT.PUT_LINE('VARRAY Last    ' || v_varray.LAST);
  
END;

DECLARE

  -- index-by type and variable
  TYPE v_index_by_t IS TABLE OF VARCHAR2(30)
    INDEX BY BINARY_INTEGER;
  v_ib v_index_by_t;
  
BEGIN

  -- add 3 entries
  v_ib(1) := 'A';
  v_ib(2) := 'B';
  v_ib(3) := 'C';
  
  DBMS_OUTPUT.PUT_LINE('...when 3 entries added...');
  DBMS_OUTPUT.PUT_LINE('Index By Count ' || v_ib.COUNT);
  DBMS_OUTPUT.PUT_LINE('Index By First ' || v_ib.FIRST);
  DBMS_OUTPUT.PUT_LINE('Index By Last  ' || v_ib.LAST);

  DBMS_OUTPUT.PUT_LINE('...simple for loop..');
  FOR counter IN 1..v_ib.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE(counter || ' ' || v_ib(counter));
  END LOOP;

  DBMS_OUTPUT.PUT_LINE('...first and next..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_ib.FIRST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_ib(v_counter));
      v_counter := v_ib.NEXT(v_counter);
    END LOOP;
  END;

  DBMS_OUTPUT.PUT_LINE('...last and prior..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_ib.LAST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_ib(v_counter));
      v_counter := v_ib.PRIOR(v_counter);
    END LOOP;
  END;
 
END;

DECLARE

  -- table type and variable
  TYPE v_table_t IS TABLE OF VARCHAR2(30);
  v_table v_table_t := v_table_t();
  
BEGIN

  -- add 3 entries
  v_table.EXTEND(3);    
  v_table(1) := 'A';
  v_table(2) := 'B';
  v_table(3) := 'C';
  
  DBMS_OUTPUT.PUT_LINE('...when 3 entries added...');
  DBMS_OUTPUT.PUT_LINE('Table Count ' || v_table.COUNT);
  DBMS_OUTPUT.PUT_LINE('Table First ' || v_table.FIRST);
  DBMS_OUTPUT.PUT_LINE('Table Last  ' || v_table.LAST);

  DBMS_OUTPUT.PUT_LINE('...simple for loop..');
  FOR counter IN 1..v_table.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE(counter || ' ' || v_table(counter));
  END LOOP;

  DBMS_OUTPUT.PUT_LINE('...first and next..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_table.FIRST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_table(v_counter));
      v_counter := v_table.NEXT(v_counter);
    END LOOP;
  END;

  DBMS_OUTPUT.PUT_LINE('...last and prior..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_table.LAST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_table(v_counter));
      v_counter := v_table.PRIOR(v_counter);
    END LOOP;
  END;
 
END;

DECLARE

  -- table type and variable
  TYPE v_varray_t IS TABLE OF VARCHAR2(30);
  v_varray v_varray_t := v_varray_t();
  
BEGIN

  -- add 3 entries
  v_varray.EXTEND(3);    
  v_varray(1) := 'A';
  v_varray(2) := 'B';
  v_varray(3) := 'C';
  
  DBMS_OUTPUT.PUT_LINE('...when 3 entries added...');
  DBMS_OUTPUT.PUT_LINE('Table Count ' || v_varray.COUNT);
  DBMS_OUTPUT.PUT_LINE('Table First ' || v_varray.FIRST);
  DBMS_OUTPUT.PUT_LINE('Table Last  ' || v_varray.LAST);

  DBMS_OUTPUT.PUT_LINE('...simple for loop..');
  FOR counter IN 1..v_varray.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE(counter || ' ' || v_varray(counter));
  END LOOP;

  DBMS_OUTPUT.PUT_LINE('...first and next..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_varray.FIRST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_varray(v_counter));
      v_counter := v_varray.NEXT(v_counter);
    END LOOP;
  END;

  DBMS_OUTPUT.PUT_LINE('...last and prior..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_varray.LAST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_varray(v_counter));
      v_counter := v_varray.PRIOR(v_counter);
    END LOOP;
  END;
 
END;

DECLARE

  -- table type and variable
  TYPE v_varray_t IS VARRAY(3) OF VARCHAR2(30);
  v_varray v_varray_t := v_varray_t();
  
BEGIN

  -- add 3 entries
  v_varray.EXTEND(3);    
  v_varray(1) := 'A';
  v_varray(2) := 'B';
  v_varray(3) := 'C';
  
  DBMS_OUTPUT.PUT_LINE('...when 3 entries added...');
  DBMS_OUTPUT.PUT_LINE('Table Count ' || v_varray.COUNT);
  DBMS_OUTPUT.PUT_LINE('Table First ' || v_varray.FIRST);
  DBMS_OUTPUT.PUT_LINE('Table Last  ' || v_varray.LAST);

  DBMS_OUTPUT.PUT_LINE('...simple for loop..');
  FOR counter IN 1..v_varray.COUNT LOOP
    DBMS_OUTPUT.PUT_LINE(counter || ' ' || v_varray(counter));
  END LOOP;

  DBMS_OUTPUT.PUT_LINE('...first and next..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_varray.FIRST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_varray(v_counter));
      v_counter := v_varray.NEXT(v_counter);
    END LOOP;
  END;

  DBMS_OUTPUT.PUT_LINE('...last and prior..');
  DECLARE
    v_counter BINARY_INTEGER;
  BEGIN
    v_counter := v_varray.LAST;
    LOOP
      EXIT WHEN v_counter IS NULL;
      DBMS_OUTPUT.PUT_LINE(v_counter || ' ' || v_varray(v_counter));
      v_counter := v_varray.PRIOR(v_counter);
    END LOOP;
  END;
 
END;
