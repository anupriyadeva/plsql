DECLARE
  CURSOR v_curs IS 
  SELECT *
    FROM animal;
  v_animal v_curs%ROWTYPE;
BEGIN
  OPEN v_curs;
  LOOP
    FETCH v_curs INTO v_animal;
    EXIT WHEN v_curs%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE(v_animal.animal_id || ' ' || v_animal.animal_name);
  END LOOP;
  CLOSE v_curs;
END;