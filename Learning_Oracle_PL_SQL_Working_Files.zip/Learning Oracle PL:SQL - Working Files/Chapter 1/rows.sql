DECLARE
  -- variable anchored to a whole row
  v_animal_row animal%ROWTYPE;
BEGIN
  v_animal_row.animal_id := 2;
  v_animal_row.animal_name := 'Panda';
END;

DECLARE
  -- variable anchored to a whole row
  -- with quert
  v_animal_row animal%ROWTYPE;
BEGIN
  SELECT *
    INTO v_animal_row
    FROM animal;
END;

DECLARE
  -- variable anchored to a whole row
  v_animal_row animal%ROWTYPE;
BEGIN
  v_animal_row.animal_id := 2;
  v_animal_row.animal_name := 'Panda';
  INSERT INTO animal
  VALUES v_animal_row;
END;

SELECT *
  FROM animal
  
COMMIT;
