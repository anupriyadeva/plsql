-- procedure with IN parameter
CREATE OR REPLACE PROCEDURE db_proc ( p_var IN VARCHAR2 := 'Default' ) AS
BEGIN
  DBMS_OUTPUT.PUT_LINE(p_var);
END;

BEGIN
  db_proc;
  db_proc('Not Default');
END;

-- procedure with parameter IN OUT
CREATE OR REPLACE PROCEDURE db_proc ( p_var IN OUT VARCHAR2 ) AS
BEGIN
  p_var := p_var || '1';
  DBMS_OUTPUT.PUT_LINE(p_var);
END;

DECLARE
  v_local_var VARCHAR2(100) := 'ABC';
BEGIN
  db_proc(v_local_var);
  DBMS_OUTPUT.PUT_LINE('Returned Value ' || v_local_var);
END;

-- procedure with IN parameter and OUT parameter
CREATE OR REPLACE PROCEDURE db_proc ( p_var_in  IN  VARCHAR2 := 'Default',
                                      p_var_out OUT VARCHAR2 ) AS
BEGIN
  DBMS_OUTPUT.PUT_LINE(p_var_in);
  p_var_out := p_var_in || '1';
END;

-- positional AND explicit notation
DECLARE
  v_local_var VARCHAR2(100);
BEGIN
  db_proc( 'ABC', v_local_var);
  DBMS_OUTPUT.PUT_LINE('Returned Value ' || v_local_var);
  db_proc( p_var_out => v_local_var);
  DBMS_OUTPUT.PUT_LINE('Returned Value ' || v_local_var);
END;

CREATE OR REPLACE PROCEDURE db_proc ( p_animal animal%ROWTYPE ) AS
BEGIN
  DBMS_OUTPUT.PUT_LINE(p_animal.animal_name);
END;

BEGIN
  FOR v_animal IN ( SELECT *
                      FROM animal ) LOOP
    db_proc(v_animal);
  END LOOP;
END;