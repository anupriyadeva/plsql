-- anonymous block
BEGIN
  DBMS_OUTPUT.PUT_LINE('DB Procedure');
END;

-- creating a procedure
CREATE PROCEDURE db_proc AS
BEGIN
  DBMS_OUTPUT.PUT_LINE('DB Procedure');
END;

BEGIN
  db_proc;
END;

-- query db object for procedure
SELECT object_type,
       object_name,
       status
  FROM user_objects
 WHERE object_name = 'DB_PROC'

-- procedure with runtime error
CREATE OR REPLACE PROCEDURE db_proc AS
BEGIN
  RAISE_APPLICATION_ERROR(-20000,'Error In Proc');
END;

SELECT *
  FROM animal

-- procedure that references a DB table
CREATE OR REPLACE PROCEDURE db_proc AS
BEGIN
  DELETE animal;
END;

ALTER TABLE animal
MODIFY ( animal_name VARCHAR2(10) );

SELECT object_type,
       object_name,
       status
  FROM user_objects
 WHERE object_name = 'DB_PROC'
 
ALTER PROCEDURE db_proc compile;

BEGIN
  db_proc;
  db_proc;
END;

SELECT parse_calls,
       executions
  FROM v$sql
 WHERE INSTR(sql_text,'DELETE ANIMAL') > 0
   AND INSTR(sql_text,'SELECT') = 0