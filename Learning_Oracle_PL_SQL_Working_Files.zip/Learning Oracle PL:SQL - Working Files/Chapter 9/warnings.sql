SET SQLFORMAT ANSICONSOLE
SET LINES 132
SET PAGES 3000

CREATE OR REPLACE PROCEDURE abc AS
  v_var NUMBER := 99;
  FUNCTION not_used RETURN NUMBER IS
  BEGIN
    RETURN(11);
  END;
BEGIN
  IF v_var <> 99 THEN
    DBMS_OUTPUT.PUT_LINE('ABC');
  ELSE
    DBMS_OUTPUT.PUT_LINE('NOT ABC');
  END IF;
END;

SELECT name,
       attribute,
       text,
       message_number,
       line,
       position
  FROM USER_ERRORS
ORDER BY name, sequence

-- just want to see what these return
ALTER SESSION SET PLSQL_WARNINGS='ENABLE:INFORMATIONAL','ENABLE:SEVERE'

-- want any of these to stop compilation
ALTER SESSION SET PLSQL_WARNINGS='ERROR:INFORMATIONAL','ERROR:SEVERE'

-- want to see the severe ones but want informational ones to stop compilation
ALTER SESSION SET PLSQL_WARNINGS='ERROR:INFORMATIONAL','ENABLE:SEVERE'

-- want info about AUTHID message (5018) but any other severe ones or
-- informational ones will stop compilation
ALTER SESSION SET PLSQL_WARNINGS='ERROR:INFORMATIONAL','ERROR:SEVERE','ENABLE:05018'

-- want to ignore AUTHID message (5018) but any other severe ones or
-- informational ones will stop compilation
ALTER SESSION SET PLSQL_WARNINGS='ERROR:INFORMATIONAL','ERROR:SEVERE','DISABLE:05018'

-- want to ignore AUTHID message (5018) see info on uncalled code (06006) but
-- fail on unreachable code
ALTER SESSION SET PLSQL_WARNINGS='ERROR:INFORMATIONAL','ERROR:SEVERE','DISABLE:05018','ENABLE:06006'

-- dont want to see anything
ALTER SESSION SET PLSQL_WARNINGS='DISABLE:INFORMATIONAL','DISABLE:SEVERE'

BEGIN
  DBMS_OUTPUT.PUT_LINE(DBMS_WARNING.GET_WARNING_SETTING_STRING);
END;

BEGIN
  DBMS_WARNING.ADD_WARNING_SETTING_CAT('SEVERE','ERROR','SESSION');
  DBMS_OUTPUT.PUT_LINE(DBMS_WARNING.GET_WARNING_SETTING_STRING);
END;

BEGIN
  -- check category of authid message
  DBMS_OUTPUT.PUT_LINE(DBMS_WARNING.GET_CATEGORY(5018));
END;

ALTER PROCEDURE abc COMPILE PLSQL_WARNINGS='DISABLE:ALL'

SELECT plsql_warnings
  FROM user_plsql_object_settings
 WHERE name = 'ABC'