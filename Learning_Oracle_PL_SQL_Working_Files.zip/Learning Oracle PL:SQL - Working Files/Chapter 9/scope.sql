SET SQLFORMAT ANSICONSOLE
SET PAGESIZE 300
SET LINESIZE 32767

COLUMN full_output FORMAT a150

ALTER SESSION SET PLSCOPE_SETTINGS = 'IDENTIFIERS:ALL';

CREATE OR REPLACE PROCEDURE abc AS
  v_variable NUMBER;
BEGIN
  v_variable := 11;
END;

-- see what identifiers have been loaded
SELECT *
  FROM user_identifiers

-- query hierarch of identifiers
SELECT level,
       object_name,
       object_type,
       name,
       type,
       usage,
       line
  FROM user_identifiers
START WITH USAGE_CONTEXT_ID = 0
CONNECT BY PRIOR USAGE_ID = USAGE_CONTEXT_ID
ORDER SIBLINGS BY line, col

CREATE OR REPLACE PACKAGE pkg AS
  v_variable NUMBER := 22;
  PROCEDURE pkg_abc;
END;

CREATE OR REPLACE PACKAGE BODY pkg AS
  PROCEDURE pkg_abc IS
  BEGIN
    abc;
  END;
END;


SELECT LPAD('=',level,'=') || ' '  ||
       level       || ' ' ||
--       owner       || ' ' ||
       object_name || ' ' ||
       object_type || ' ' ||
       name        || ' ' ||
       type        || ' ' ||
       usage       || ' ' ||
       line        || ' ' ||
--       ( SELECT text
--           FROM user_source
--          WHERE name = object_name
--            AND type = object_type
--            AND line = ai.line ) full_output
  FROM all_identifiers ai
-- WHERE owner <> 'SYS'
--   AND owner <> 'PUBLIC'
--   AND usage <> 'REFERENCE'
START WITH USAGE_CONTEXT_ID = 0
CONNECT BY PRIOR USAGE_ID = USAGE_CONTEXT_ID
ORDER SIBLINGS BY line, col

-- which v_variable?
SELECT object_type,
       signature
  FROM user_identifiers
 WHERE name = 'V_VARIABLE'

-- check plsqlcope settings for objects
SELECT name,
       plscope_settings
  FROM user_plsql_object_settings;

ALTER SESSION SET PLSCOPE_SETTINGS = 'IDENTIFIERS:NONE';

ALTER PACKAGE pkg COMPILE PLSCOPE_SETTINGS='IDENTIFIERS:NONE'
ALTER PROCEDURE abc COMPILE;

-- check spaces used by identifiers
SELECT SPACE_USAGE_KBYTES
  FROM V$SYSAUX_OCCUPANTS
 WHERE OCCUPANT_NAME='PL/SCOPE'
