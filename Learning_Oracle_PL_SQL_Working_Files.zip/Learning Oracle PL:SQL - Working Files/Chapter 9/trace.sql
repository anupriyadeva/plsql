SET SQLFORMAT ANSICONSOLE
SET LINES 200
SET PAGES 80

CREATE OR REPLACE PROCEDURE abc AS
  v NUMBER;
  FUNCTION def RETURN NUMBER IS
  BEGIN
    RETURN(10);
  END;
BEGIN
  v := def;
  FOR counter IN 1..5 LOOP
    DBMS_OUTPUT.PUT_LINE(counter);
  END LOOP;
  v := def;
END;

BEGIN
  DBMS_TRACE.SET_PLSQL_TRACE(DBMS_TRACE.TRACE_ALL_LINES);
  abc;
  DBMS_TRACE.CLEAR_PLSQL_TRACE;
END;

SELECT runid
  FROM plsql_trace_runs

COLUMN event_unit FORMAT a10
COLUMN event_line FORMAT 99
COLUMN txt FORMAT a50
  
SELECT event_unit,
       event_line,
       ( SELECT text
           FROM user_source
          WHERE name = event_unit
            AND line = event_line ) txt
  FROM plsql_trace_events
 WHERE runid = 1
   AND event_unit = 'ABC'
ORDER BY event_seq

ALTER PROCEDURE abc COMPILE PLSQL_DEBUG=TRUE

BEGIN
  abc;
END;