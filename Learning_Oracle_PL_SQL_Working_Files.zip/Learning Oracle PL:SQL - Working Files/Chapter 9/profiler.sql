SET SQLFORMAT ANSICONSOLE
SET LINES 200
SET PAGES 80

CREATE OR REPLACE PROCEDURE abc AS
BEGIN
  FOR counter IN 1..5 LOOP
    DBMS_OUTPUT.PUT_LINE(counter);
  END LOOP;
END;

DECLARE
  v_runid NUMBER;
BEGIN
  v_runid := DBMS_PROFILER.START_PROFILER;
  DBMS_OUTPUT.PUT_LINE('Run ID ' || v_runid);
END;

BEGIN
  abc;
END;

BEGIN
  DBMS_PROFILER.STOP_PROFILER;
END;

SELECT runid
  FROM PLSQL_PROFILER_RUNS
 WHERE runid = 1
 
SELECT unit_name,
       line#,
       d.total_occur,
       d.total_time
  FROM plsql_profiler_data d,
       plsql_profiler_units u
 WHERE d.runid = u.runid
   AND d.unit_number = u.unit_number
   AND unit_name = 'ABC'
   AND d.runid = 1
   AND d.total_time > 0
   AND d.total_occur > 0
ORDER BY unit_name, line#

BEGIN
  DBMS_HPROF.START_PROFILING('PROFILER',
                             'abc.txt');
END;

BEGIN
  abc;
END;

BEGIN
  DBMS_HPROF.STOP_PROFILING;
END;

DECLARE
  v_runid NUMBER;
BEGIN
  v_runid := DBMS_HPROF.ANALYZE('PROFILER',
                                'abc.txt');
  DBMS_OUTPUT.PUT_LINE(v_runid);
END;

SELECT runid
  FROM dbmshp_runs

COLUMN symbolid FORMAT a10
COLUMN module   FORMAT a15
COLUMN function FORMAT a25
  
SELECT symbolid,
       module,
       function
  FROM dbmshp_function_info
 WHERE runid = 1
ORDER BY symbolid

COLUMN parent FORMAT a50
COLUMN child FORMAT a50
COLUMN subtree_elapsed_time FORMAT 99999
COLUMN function_elapsed_time FORMAT 99999

SELECT ( SELECT module || ' ' || function
           FROM dbmshp_function_info
          WHERE symbolid = parentsymid ) parent,
       ( SELECT module || ' ' || function
           FROM dbmshp_function_info
          WHERE symbolid = childsymid )  child,
       subtree_elapsed_time,
       function_elapsed_time
  FROM dbmshp_parent_child_info
 WHERE runid = 1
ORDER BY parentsymid, childsymid
