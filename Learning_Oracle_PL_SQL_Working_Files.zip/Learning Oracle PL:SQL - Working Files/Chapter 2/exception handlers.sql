-- flow control with exception handler that does not re-raise error
DECLARE
  v_number NUMBER;
BEGIN
  -- start embedded block
  BEGIN
    v_number := 'ABC';
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('When Others');
  END;
  -- end embedded block
  DBMS_OUTPUT.PUT_LINE('Next Line');
END;

-- flow control with exception handler that does re-raise the error
DECLARE
  v_number NUMBER;
BEGIN
  -- start embedded block
  BEGIN
    v_number := 'ABC';
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('When Others');
      RAISE;
  END;
  -- end embedded block
  DBMS_OUTPUT.PUT_LINE('Next Line');
END;

-- flow control with exception handler that does re-raise the error
-- which then gets trapped
DECLARE
  v_number NUMBER;
BEGIN
  -- start embedded block
  BEGIN
    v_number := 'ABC';
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('When Others');
      RAISE;
  END;
  -- end embedded block
  DBMS_OUTPUT.PUT_LINE('Next Line');
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Other When Others');
END;

-- raise an error directly
BEGIN
  RAISE NO_DATA_FOUND;
END;

-- raise an error directly, handle it and
-- raise something else
BEGIN
  RAISE NO_DATA_FOUND;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE DUP_VAL_ON_INDEX;
END;

-- Exception handlers can affect transactions
SELECT *
  FROM animal;

BEGIN
  INSERT INTO animal
  VALUES(3,'Elephant');
  INSERT INTO animal
  VALUES(2,'Lion');
  INSERT INTO animal
  VALUES(4,'Hippo');
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    NULL;
END;

ROLLBACK