/*
There are 20+ predefined exceptions
Here are the ones we will discuss
DUP_VAL_ON_INDEX ORA-00001   -1
NO_DATA_FOUND    ORA-01403   +100
TOO_MANY_ROWS    ORA-01422   -1422
ZERO_DIVIDE      ORA-01476   -1476
*/

-- use of generic when others handler
DECLARE
  v_number NUMBER := 11;
BEGIN
  v_number := v_number / 0;
EXCEPTION
  -- using generic handler
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('OTHERS ' || SQLCODE);
    DBMS_OUTPUT.PUT_LINE('OTHERS ' || SQLERRM);
END;

-- use of pre-defined handler and when others
DECLARE
  v_number NUMBER := 11;
BEGIN
  v_number := v_number / 0;
EXCEPTION
  -- handler for zero divide errors
  WHEN ZERO_DIVIDE THEN
    DBMS_OUTPUT.PUT_LINE('ZERO ' || SQLCODE);
    DBMS_OUTPUT.PUT_LINE('ZERO ' || SQLERRM);  
  -- handler for ALL OTHER errors
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('OTHERS ' || SQLCODE);
    DBMS_OUTPUT.PUT_LINE('OTHERS ' || SQLERRM);
END;

-- no data found and too many rows when querying
-- records from DB
DECLARE
  v_animal_name animal.animal_name%TYPE;
BEGIN
  SELECT animal_name
    INTO v_animal_name
    FROM animal;
--   WHERE animal_id = 99;
--EXCEPTION
--  WHEN TOO_MANY_ROWS THEN
--    DBMS_OUTPUT.PUT_LINE('Too many rows...');
--  WHEN NO_DATA_FOUND THEN
--    DBMS_OUTPUT.PUT_LINE('No Record Found');
--    -- NO_DATA_FOUND is equal to ORA-01403 but shows as SQLCODE 100
--    DBMS_OUTPUT.PUT_LINE(SQLCODE);
END;

SELECT *
  FROM animal;

-- dup val on index exception
BEGIN
  INSERT INTO animal
  VALUES(2,'Lion');
EXCEPTION
  WHEN dup_val_on_index THEN
    UPDATE animal
    SET animal_name = 'Lion'
    WHERE animal_id = 2;
END;
