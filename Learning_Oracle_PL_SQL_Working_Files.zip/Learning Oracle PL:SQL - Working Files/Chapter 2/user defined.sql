CREATE TABLE demo ( col1 NUMBER CHECK ( col1 <= 10 ));

-- insert will fail
BEGIN
  INSERT INTO demo
  VALUES(11);
END;

-- insert with explicit exception caught
DECLARE
  e_not_less_than_ten EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_not_less_than_ten,-2290);
BEGIN
  INSERT INTO demo
  VALUES(11);
EXCEPTION
  WHEN e_not_less_than_ten THEN
    DBMS_OUTPUT.PUT_LINE('Please Use Value Less Than 10');
END;

-- dont define exceptions for errors that dont really match up
DECLARE
  e_too_big EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_too_big,-1);
  v_number NUMBER := 12;
BEGIN
  IF v_number > 10 THEN
    RAISE e_too_big;
  END IF;
END;

-- use RAISE_APPLICATION_ERROR to raise specific error number
-- then define exception based on that
DECLARE
  v_number NUMBER := 12;
  e_too_big EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_too_big,-20000);
BEGIN
  IF v_number > 10 THEN
    RAISE_APPLICATION_ERROR(-20000,'Value Too Big');
  END IF;
EXCEPTION
  WHEN e_too_big THEN
    DBMS_OUTPUT.PUT_LINE('Seriously - its too big!');
END;
