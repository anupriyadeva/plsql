SET SQLFORMAT ANSICONSOLE
COLUMN session_id FORMAT 9999
COLUMN object_name FORMAT a30

-- locks
SELECT session_id,
       ( select object_name
           from dba_objects
          where object_id = vlo.object_id ) object_name,
       CASE locked_mode
         WHEN 2 THEN 'Table Share'
         WHEN 3 THEN 'Row Exclusive'
         WHEN 4 THEN 'Table Share'
         WHEN 5 THEN 'Lock Table Share'
         WHEN 6 THEN 'Lock Table Exclusive'
         ELSE '??'
       END CASE
  FROM v$locked_object vlo

-- rollback
SELECT object_name
  FROM v$transaction,
       v$session,
       v$locked_object vlo,
       dba_objects     do
 WHERE saddr = ses_addr
   AND session_id = sid
   AND vlo.object_id = do.object_id