SET SQLFORMAT ANSICONSOLE

CREATE TABLE animal
( animal_id   NUMBER NOT NULL PRIMARY KEY,
  animal_name VARCHAR2(30));
  
-- create procedure that is an autonomous transaction
CREATE OR REPLACE PROCEDURE create_animal ( p_id   NUMBER,
                                            p_name VARCHAR2 ) IS
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  INSERT INTO animal
  VALUES(p_id,p_name);
  COMMIT;
END;

-- insert 2 records an roll back
BEGIN
  INSERT INTO animal
  VALUES(1,'Zebra');
  create_animal(2,'Panda');
  ROLLBACK;
END;

SELECT *
  FROM animal
  
-- table to log errors
CREATE TABLE error_log
( program_name VARCHAR2(30),
  timestamp    DATE,
  error_number  NUMBER);

-- violate a PK and insert a log entry
BEGIN
  INSERT INTO animal VALUES(2,'Other Panda');
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    DECLARE
      e_code NUMBER := SQLCODE;
    BEGIN
      INSERT INTO error_log
      VALUES('CREATE ANIMAL',
             SYSDATE,
             e_code);  
    END;
END;

SELECT *
  FROM error_log
  
ROLLBACK

-- an autonomous transaction procedure to save the error
CREATE OR REPLACE PROCEDURE save_error ( p_prog VARCHAR2,
                                         p_err  NUMBER ) IS
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  INSERT INTO error_log
  VALUES(p_prog,
         SYSDATE,
         p_err);
--  COMMIT;
END;

-- violate the pk and save the error
BEGIN
  INSERT INTO animal VALUES(2,'Other Panda');
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    DECLARE
      e_code NUMBER := SQLCODE;
    BEGIN
      save_error('CREATE ANIMAL',
                  e_code);
    END;
END;
