SELECT DISTINCT SID
  FROM v$mystat
  
CREATE TABLE animal
( animal_id   NUMBER PRIMARY KEY,
  animal_name VARCHAR2(30) );
  
BEGIN
  INSERT INTO animal VALUES(1,'Zebra');
END;

SELECT *
  FROM animal

-- commit in plsql
BEGIN
  COMMIT;
END;

BEGIN
  DELETE animal;
  COMMIT;
END;

BEGIN
  INSERT INTO animal VALUES(1,'Zebra1');
  INSERT INTO animal VALUES(2,'Panda1');
  ROLLBACK; -- previous 2 inserts rolled back
  INSERT INTO animal VALUES(1,'Zebra2');
  INSERT INTO animal VALUES(2,'Panda2');
  COMMIT;   -- previous 2 inserts committed
  INSERT INTO animal VALUES(1,'Zebra3'); -- causes PK viloation
  INSERT INTO animal VALUES(2,'Panda3'); -- never runs
  INSERT INTO animal VALUES(3,'Lion3');  -- never runs
END;

SELECT *
  FROM animal
  
-- for update locks records for update as it queries them
-- and holds them until a commit or rollback occurs
DECLARE
  v_animal animal%ROWTYPE;
BEGIN
  SELECT *
    INTO v_animal
    FROM animal
   WHERE animal_id = 1
  FOR UPDATE of animal_name;
END;

-- use of where current of for specific record
DECLARE
  CURSOR curs_get_animal IS
  SELECT *
    FROM animal
   WHERE animal_id = 1
  FOR UPDATE of animal_name;
  v_animal animal%ROWTYPE;
BEGIN
  OPEN curs_get_animal;
  FETCH curs_get_animal INTO v_animal;
  UPDATE animal
  SET animal_name = 'Hippo'
  WHERE CURRENT OF curs_get_animal;
  CLOSE curs_get_animal;
END;

-- use of no wait
-- add exception handler to this example
DECLARE
  CURSOR curs_get_animal IS
  SELECT *
    FROM animal
   WHERE animal_id = 1
  FOR UPDATE of animal_name NOWAIT;
  v_animal animal%ROWTYPE;
BEGIN
  OPEN curs_get_animal;
  FETCH curs_get_animal INTO v_animal;
  UPDATE animal
  SET animal_name = 'Hippo'
  WHERE CURRENT OF curs_get_animal;
  CLOSE curs_get_animal;
--EXCEPTION
--  WHEN exception_list.e_resource_busy THEN
--    DBMS_OUTPUT.PUT_LINE('Waited Too Long...');
END;

CREATE OR REPLACE PACKAGE exception_list AS
  e_resource_busy EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_resource_busy,-54);
END;

-- updates rolled back even when row that fails is not
-- the first one processed
DECLARE
  CURSOR curs_get_animal IS
  SELECT *
    FROM animal
  ORDER BY animal_id
  FOR UPDATE of animal_name NOWAIT;
  v_animal animal%ROWTYPE;
BEGIN
  OPEN curs_get_animal;
  LOOP
    FETCH curs_get_animal INTO v_animal;
    EXIT WHEN curs_get_animal%NOTFOUND;
    UPDATE animal
    SET animal_name = 'Hippo'
    WHERE CURRENT OF curs_get_animal;
    DBMS_OUTPUT.PUT_LINE('Updated ' || v_animal.animal_id);
  END LOOP;
  CLOSE curs_get_animal;
EXCEPTION
  WHEN exception_list.e_resource_busy THEN
    DBMS_OUTPUT.PUT_LINE('Waited Too Long...');
END;
