SELECT *
  FROM animal

DELETE animal;
COMMIT;
