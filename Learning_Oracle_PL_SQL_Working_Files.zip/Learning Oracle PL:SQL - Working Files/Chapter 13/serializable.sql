CREATE TABLE animal
( animal_id   NUMBER PRIMARY KEY,
  animal_name VARCHAR2(30) );

INSERT INTO animal VALUES(1,'Zebra');
INSERT INTO animal VALUES(2,'Panda');
COMMIT;

-- serializable means transactions would run even if they were run one after the other
-- serializable must be the first statement in tranasction
BEGIN
  EXECUTE IMMEDIATE 'SET TRANSACTION ISOLATION LEVEL SERIALIZABLE';
  UPDATE animal
  SET animal_name = 'Animal ' || animal_id;
  COMMIT;
END;

SELECT *
  FROM animal

BEGIN
  EXECUTE IMMEDIATE 'SET TRANSACTION ISOLATION LEVEL SERIALIZABLE';
END;

BEGIN
  UPDATE animal
  SET animal_name = 'Animal ' || animal_id;
  DBMS_OUTPUT.PUT_LINE('Name Set');
--EXCEPTION
--  WHEN exception_list.e_not_serializable THEN
--    DBMS_OUTPUT.PUT_LINE('Unable to serialize. Please try again');
--    ROLLBACK;
END;

CREATE OR REPLACE PACKAGE exception_list AS
  e_resource_busy EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_resource_busy,-54);
  e_not_serializable EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_not_serializable,-8177);
END;
