CREATE TABLE animal
( animal_id   NUMBER PRIMARY KEY,
  animal_name VARCHAR2(30) );
  
BEGIN
  INSERT INTO animal VALUES(1,'Zebra');
  INSERT INTO animal VALUES(2,'Panda');
  INSERT INTO animal VALUES(3,'Tiger');
END;

COMMIT;

-- insert, savepoint, insert, rollback to savepoint
BEGIN
  INSERT INTO animal VALUES(4,'Lion');
  SAVEPOINT savepoint1;
  INSERT INTO animal VALUES(5,'Hippo');
  ROLLBACK TO savepoint1;
END;
  
SELECT *
  FROM animal
ORDER BY animal_id

-- savepoints do not survive across commits or rollback
BEGIN
  SAVEPOINT before_update;
  UPDATE animal
  SET animal_name = 'Large ' || animal_name;
  COMMIT;
  ROLLBACK TO before_update;
EXCEPTION
  WHEN exceptions.e_bad_savepoint THEN
    DBMS_OUTPUT.PUT_LINE('Invalid Savepoint Used');
END;

COMMIT;

CREATE OR REPLACE PACKAGE exceptions AS
  e_bad_savepoint EXCEPTION;
  PRAGMA EXCEPTION_INIT(e_bad_savepoint,-1086);
END;

-- can rollback from exception handlers to savepoint
-- in main code block
BEGIN
  SAVEPOINT before_ins;
  INSERT INTO animal VALUES(3,'Tigger');
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    DBMS_OUTPUT.PUT_LINE('Duplicate ID');
    ROLLBACK TO before_ins;
END;

COMMIT;

-- cant rollback to savepoint in another exception handler
BEGIN
  INSERT INTO animal VALUES(3,'Tigger');
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    DBMS_OUTPUT.PUT_LINE('Duplicate ID');
    ROLLBACK TO before_ins;
  WHEN OTHERS THEN
    SAVEPOINT before_ins;
END;

CREATE OR REPLACE PROCEDURE savepoint_proc AS
BEGIN
  SAVEPOINT in_savepoint;
  INSERT INTO animal VALUES(100,'Animal 100');
END;

BEGIN
  INSERT INTO animal VALUES(98,'Animal 98');
  savepoint_proc;
  INSERT INTO animal VALUES(99,'Animal 99');
  ROLLBACK TO in_savepoint;
END;

SELECT *
  FROM animal

DELETE animal;
COMMIT;

BEGIN
  FOR counter IN 1..10 LOOP
    SAVEPOINT animal_sp;
    INSERT INTO animal
    VALUES(counter,'Animal ' || counter);
    IF MOD(counter,2) = 0 THEN
      ROLLBACK TO animal_sp;
    END IF;
  END LOOP;
END;

SELECT *
  FROM animal
ORDER BY animal_id
