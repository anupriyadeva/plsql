CREATE TABLE animal
( animal_id   NUMBER PRIMARY KEY,
  animal_name VARCHAR2(30) );

INSERT INTO animal VALUES(1,'Zebra');
INSERT INTO animal VALUES(2,'Panda');
COMMIT;

SELECT *
  FROM animal
  
-- read only transaction must be first statement in transaction
BEGIN
  DBMS_TRANSACTION.READ_ONLY;
  FOR x IN 1..5 LOOP
    FOR v IN ( SELECT *
                 FROM animal
               ORDER BY animal_id) LOOP
      DBMS_OUTPUT.PUT_LINE('Loop ' || x || ' ' || v.animal_name);
    END LOOP;
    DBMS_LOCK.SLEEP(3);
  END LOOP;
END;

COMMIT
