SET SQLFORMAT ANSICONSOLE

CREATE TABLE animal
( animal_id   NUMBER PRIMARY KEY,
  animal_name VARCHAR2(30));
  
BEGIN
  INSERT INTO animal VALUES(1,'Zebra');
  INSERT INTO animal VALUES(2,'Panda');
  COMMIT;
END;

/*
  -------------------------------------------------------------------
  - Calling a PLSQL function in select portion of an SQL query
  -------------------------------------------------------------------
*/
-- function to reverse string
CREATE OR REPLACE FUNCTION reverser ( p_name VARCHAR2 )
                  RETURN VARCHAR2 IS
  v_ret_val VARCHAR2(100);
BEGIN
  FOR counter IN REVERSE 1..LENGTH(p_name) LOOP
    v_ret_val := v_ret_val || SUBSTR(p_name,counter,1);
  END LOOP;
  RETURN(v_ret_val);
END;

-- plsql function called in select list of sql query
SELECT reverser(animal_name)
  FROM animal
  
/*
  -------------------------------------------------------------------
  - Querying a PLSQL function in SQL
  -------------------------------------------------------------------
*/
-- types to hold return values
CREATE OR REPLACE TYPE name_jumble_o AS OBJECT ( normal_name   VARCHAR2(30),
                                                 reversed_name VARCHAR2(30) );
CREATE OR REPLACE TYPE name_jumble_t AS TABLE OF name_jumble_o;

-- function that returns records types
CREATE OR REPLACE FUNCTION name_jumble
                  RETURN name_jumble_t
                  PIPELINED AS
BEGIN
  FOR v_animal IN ( SELECT *
                      FROM animal ) LOOP
    PIPE ROW(name_jumble_o(v_animal.animal_name,reverser(v_animal.animal_name)));
  END LOOP;
END;

-- SQL query from a function with the TABLE function
SELECT *
  FROM TABLE(name_jumble)
 WHERE normal_name = 'Zebra'

/*
  -------------------------------------------------------------------
  - PLSQL functions in the WITH clause (12c and higher)
  -------------------------------------------------------------------
*/
WITH FUNCTION rev ( p_name VARCHAR2 )
     RETURN VARCHAR2 AS
    v_ret_val VARCHAR2(100);
  BEGIN
    FOR counter IN REVERSE 1..LENGTH(p_name) LOOP
      v_ret_val := v_ret_val || SUBSTR(p_name,counter,1);
    END LOOP;
    RETURN(v_ret_val);
  END;
SELECT rev(animal_name)
  FROM animal

/*
  -------------------------------------------------------------------
  - PLSQL procedures in the WITH clause (12c and higher)
  -------------------------------------------------------------------
*/
WITH PROCEDURE proc ( p_name IN OUT VARCHAR2 ) AS
    v_temp VARCHAR2(30);
  BEGIN
    FOR counter IN REVERSE 1..LENGTH(p_name) LOOP
      v_temp := v_temp || SUBSTR(p_name,counter,1);
    END LOOP;
    p_name := v_temp;
  END;
  FUNCTION rev ( p_name VARCHAR2 )
     RETURN VARCHAR2 AS
    v_ret_val VARCHAR2(30);
  BEGIN
    v_ret_val := p_name;
    proc(v_ret_val);
    RETURN(v_ret_val);
  END;
SELECT rev(animal_name)
  FROM animal

/*
  -------------------------------------------------------------------
  - PLSQL in DML (12c and higher)
  - Does not work in some versions of SQL Developer
  -------------------------------------------------------------------
*/
DELETE /*+ WITH_PLSQL */ animal a
WHERE reverser(animal_name) IN ( WITH FUNCTION rev ( p_name VARCHAR2 )
                                               RETURN VARCHAR2 IS
                                        v_ret_val VARCHAR2(100);
                                      BEGIN
                                        FOR counter IN REVERSE 1..LENGTH(p_name) LOOP
                                          v_ret_val := v_ret_val || SUBSTR(p_name,counter,1);
                                        END LOOP;
                                        RETURN(v_ret_val);
                                      END;
                                 SELECT rev(a.animal_name)
                                   FROM animal );

/*
  -------------------------------------------------------------------
  - User Defined Function UDF (12c and higher)
  - usually runs faster than non-UDF function
  -------------------------------------------------------------------
*/
CREATE OR REPLACE FUNCTION reverser ( p_name VARCHAR2 )
                  RETURN VARCHAR2 IS
  PRAGMA UDF;
  v_ret_val VARCHAR2(100);
BEGIN
  FOR counter IN REVERSE 1..LENGTH(p_name) LOOP
    v_ret_val := v_ret_val || SUBSTR(p_name,counter,1);
  END LOOP;
  RETURN(v_ret_val);
END;

SELECT reverser(animal_name)
  FROM animal
